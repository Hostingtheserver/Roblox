import os
import time as t

mypath2 = "C:/Users/user/Desktop/내꺼/코딩/NastyManagement"
mypath = "C:/Users/Administrator/Desktop/NastyManagement"

targetpath = mypath+f"/server/premiumdb/time"

while True:
    t.sleep(60)

    for filename in os.listdir(targetpath):
        with open(mypath+f"/server/premiumdb/time/"+filename) as f:
            time = int(f.read())
            f.close()
        
        newtime = time - 1
        if newtime <= 0:
            os.remove(mypath+f"/server/premiumdb/time/"+filename)
        else:
            with open(mypath+f"/server/premiumdb/time/"+filename, "w") as f:
                f.write(str(newtime))
                f.close()
            continue