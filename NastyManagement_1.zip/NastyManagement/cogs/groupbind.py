import discord
import os
import json
from discord.ext import commands
import requests
import random
import shutil

req = requests.Session()
botownerid = 631441731350691850

class verify(commands.Cog):

    def __init__(self, client):
        self.client = client
    
    @commands.command(aliases=["그룹연동"])
    async def groupbind(self, ctx, groupid=None):
        if ctx.guild.owner_id == ctx.author.id or ctx.author.id == botownerid:
            if groupid != None:
                serverid = ctx.guild.id
                
                onepath = f"client/{serverid}"

                exist = onepath+"/exist.json"

                if os.path.isfile(exist):
                    
                    with open(onepath+"/settings/basicsetting.json") as f:
                        basicsetting = json.load(f)
                        f.close()
                    pastgroupid = basicsetting["groupid"]
                    

                    if str(groupid) != str(pastgroupid):

                        embed = discord.Embed(
                            title = "에러 | 서버 연동된 상태",
                            description = f"❗ 현재 이미 {pastgroupid}로 연동된 그룹이 있습니다. 만약 진행하신다면 수동으로 연결했던 모든 역할들이 사라질 겁니다. 계속하시겠습니까?\n'예', '아니요'",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        await ctx.send(embed=embed)

                        def check(author):
                            def inner_check(message):
                                return message.author.id == author and message.content == "예" or message.author.id == author and message.content == "아니요"
                            return inner_check


                        try:
                            msg = await self.client.wait_for('message', check=check(ctx.author.id), timeout = 300.0)
                        except:
                            await ctx.send(f"{ctx.author.mention}, 너무 오래걸려서 프로세스가 종료됐습니다.")
                        else:                
                            if msg.content == "예":

                                embed = discord.Embed(
                                    title = "그룹 연동중",
                                    description = f"<a:loading:792942564323885067> 잠시만 기다려주세요.",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                embed1 = await ctx.send(embed=embed)

                                r = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()

                                try:
                                    groupid = r["groupId"]
                            

                                    datafile = f"server/groupbind/bindsetting.json"
                                    basicsetting = f"server/groupbind/basicsetting.json"
                                    logsetting = f"server/groupbind/logset.json"

                                    with open(logsetting) as f:
                                        logdata = json.load(f)
                                        f.close()

                                    with open(onepath+"/settings/logsetting.json", "w") as f:
                                        json.dump(logdata, f, indent=2)
                                        f.close()   

                                    
                                    with open(basicsetting) as f:
                                        basicsetting = json.load(f)
                                        f.close()
                                    
                                    basicsetting["groupid"] = groupid

                                    with open(onepath+"/settings/basicsetting.json", "w") as f:
                                        json.dump(basicsetting, f, indent=2)
                                        f.close()

                                    with open(datafile) as f:
                                        binddata = json.load(f)
                                        f.close()

                                    length = len(r["roles"])
                                    i = 0

                                    while i < length:
                                        binddata[str(r["roles"][i]["rank"])] = []
                                        i += 1
                                

                                    with open(onepath+"/settings/bindsetting.json", "w") as f:
                                        json.dump(binddata, f, indent=2)
                                        f.close()

                                    del binddata["maingroup"]


                                    with open(onepath+"/settings/nameformat.json", "w") as f:
                                        json.dump(binddata, f, indent=2)
                                    
                                    with open(exist, "w") as f:
                                        f.close()

                                    embed = discord.Embed(
                                        title = "성공 | 그룹 연동",
                                        description = f"✅ 그룹 연동을 완료했습니다.",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await embed1.edit(embed=embed)

                                except:
                                    embed = discord.Embed(
                                        title = "에러 | 부정확한 그룹아이디",
                                        description = f"❌ 제공하신 그룹아이디({groupid})는 존재하지 않습니다.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await embed1.edit(embed=embed)



                            elif msg.content == "아니요":
                                embed = discord.Embed(
                                    title = "취소 | 그룹연동",
                                    description = f"취소되었습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)
                            else:
                                return
                    
                    else:
                        embed = discord.Embed(
                            title = "에러 | 같은 그룹",
                            description = f"❗ 현재 이미 같은 그룹으로 연동이 된 상태입니다. 혹시 그룹 역할이 바뀌어 그룹 역할을 업데이트하려면 `!그룹 업데이트`를 통해 그룹 역할을 업데이트하겠습니다.",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)

                else:
                    embed = discord.Embed(
                        title = "그룹 연동중",
                        description = f"<a:loading:792942564323885067> 잠시만 기다려주세요.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    embed1 = await ctx.send(embed=embed)

                    r = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()

                    try:
                        groupid = r["groupId"]
                

                        datafile = f"server/groupbind/bindsetting.json"
                        basicsetting = f"server/groupbind/basicsetting.json"
                        logsetting = f"server/groupbind/logset.json"

                        with open(logsetting) as f:
                            logdata = json.load(f)
                            f.close()
                        

                        os.mkdir(onepath)

                        os.mkdir(onepath+"/settings")

                        with open(onepath+"/settings/logsetting.json", "w") as f:
                            json.dump(logdata, f, indent=2)
                            f.close()   
                        
                        with open(basicsetting) as f:
                            basicsetting = json.load(f)
                            f.close()
                        
                        basicsetting["groupid"] = groupid

                        with open(onepath+"/settings/basicsetting.json", "w") as f:
                            json.dump(basicsetting, f, indent=2)
                            f.close()

                        with open(datafile) as f:
                            binddata = json.load(f)
                            f.close()

                        length = len(r["roles"])
                        i = 0

                        while i < length:
                            binddata[str(r["roles"][i]["rank"])] = []
                            i += 1
                        
                        with open(onepath+"/settings/bindsetting.json", "w") as f:
                            json.dump(binddata, f, indent=2)
                            f.close()

                        del binddata["maingroup"]


                        with open(onepath+"/settings/nameformat.json", "w") as f:
                            json.dump(binddata, f, indent=2)
                        
                        with open(exist, "w") as f:
                            f.close()

                        embed = discord.Embed(
                            title = "성공 | 그룹 연동",
                            description = f"✅ 그룹 연동을 완료했습니다.",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await embed1.edit(embed=embed)

                    except:
                        embed = discord.Embed(
                            title = "에러 | 부정확한 그룹아이디",
                            description = f"❌ 제공하신 그룹아이디({groupid})는 존재하지 않습니다.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await embed1.edit(embed=embed)


            else:
                embed = discord.Embed(
                    title = "에러 | 그룹아이디 미제공",
                    description = f"연동하실 그룹아이디를 제공해주세요.\n`!그룹연동 그룹아이디`",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["그룹업데이트"])
    async def groupupdate(self, ctx):
        serverid = ctx.guild.id
        
        onepath = f"client/{serverid}"

        exist = onepath+"/exist.json"

        if ctx.guild.owner_id == ctx.author.id or ctx.author.id == botownerid:
            if os.path.isfile(exist):
                embed = discord.Embed(
                    title = "그룹 업데이트중",
                    description = f"<a:loading:792942564323885067> 조금만 기다려주세요.",
                    color = discord.Color.from_rgb(0, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                embed1 = await ctx.send(embed=embed)

                basicsetting = onepath+"/settings/basicsetting.json"
                groupbind = onepath+"/settings/bindsetting.json"
                namebind = onepath+"/settings/nameformat.json"

                with open(basicsetting) as f:
                    basicdata = json.load(f)
                    f.close()

                with open(groupbind) as f:
                    groupdata = json.load(f)
                    f.close()

                with open(namebind) as f:
                    namedata = json.load(f)
                    f.close()

                groupid = basicdata["groupid"]

                r = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()

                length = len(r["roles"])
                i = 0

                changed = 0
                whitelist = ["maingroup", "subgroup", "whitelisted"]
                while i < length:
                    rankset = r["roles"][i]["rank"]
                    try:
                        tryfind = groupdata[str(rankset)]

                    except:
                        groupdata[str(rankset)] = []

                        changed += 1

                    whitelist.append(str(rankset))
                    i += 1

                d = 0
                while d < length:
                    rankset = r["roles"][d]["rank"]
                    try:
                        tryfind = namedata[str(rankset)]
                    except:
                        namedata[str(rankset)] = []
                    d += 1
                
                
                
                for keys in list(groupdata.keys()):
                    if keys not in whitelist:
                        del groupdata[keys]

                for keys in list(namedata.keys()):
                    if keys not in whitelist:
                        del namedata[keys]

                with open(groupbind, "w") as f:
                    json.dump(groupdata, f, indent=2)
                    f.close()
                
                with open(namebind, "w") as f:
                    json.dump(namedata, f, indent=2)
                    f.close()
                
                if changed == 0:
                    embed = discord.Embed(
                        title = "성공 | 그룹 업데이트",
                        description = f"🤔 변경된 사항이 없습니다.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await embed1.edit(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "성공 | 그룹 업데이트",
                        description = f"✅ 그룹 업데이트를 완료했습니다.\n변경 개수: {changed}",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await embed1.edit(embed=embed)



            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["그룹역할"])
    async def grouprole(self, ctx, role=None):
        serverid = ctx.guild.id
        clientpath = f"client/{serverid}"
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:

            if os.path.isfile(clientpath+"/exist.json"):
                
                if role != None:

                    getroleid = role[3:-1]

                    try:
                        myrole = discord.utils.get(ctx.guild.roles, id=int(getroleid))
                        roleid = myrole.id

                        bindsetting =  f"client/{serverid}/settings/bindsetting.json"

                        with open(bindsetting) as f:
                            data = json.load(f)
                            f.close()

                        if int(roleid) in data["maingroup"]:
                            data["maingroup"].remove(int(roleid))

                            with open(bindsetting, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()

                            embed = discord.Embed(
                                title = "성공 | 그룹역할 제거",
                                description = f"{myrole.mention}을(를) 성공적으로 연동 제거했습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)

                        else:
                            data["maingroup"].append(int(roleid))

                            with open(bindsetting, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()

                            embed = discord.Embed(
                                title = "성공 | 그룹역할 연동",
                                description = f"{myrole.mention}을(를) 성공적으로 연동 추가했습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)


                    except:
                        embed = discord.Embed(
                            title = "에러 | 역할 미제공",
                            description = f"연동할 역할을 멘션해주세요.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "에러 | 역할 미제공",
                        description = f"연동하실 역할을 멘션해주세요.\n```!그룹역할 @역할멘션```",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)                    
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["역할설정"])
    async def setrole(self, ctx, rankset=None, role=None):
        serverid = ctx.guild.id
        clientpath = f"client/{serverid}"
        logsetting = f"client/{serverid}/settings/logsetting.json"
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            if os.path.isfile(clientpath+"/exist.json"):
                if rankset == None or role == None:
                    embed = discord.Embed(
                        title = "에러 | 순위, 역할 미제공",
                        description = f"순위(숫자, 아래있는 사진 맨 아랫칸), 그리고 설정하고 싶으신 역할을 언급해주세요.\n```!역할설정 순위(숫자) @역할멘션```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    embed.set_image(url="https://i.gyazo.com/thumb/1200/59ce9c7b78d7df44990b7710580f890a-png.jpg")
                    await ctx.send(embed=embed)
                else:
                    roleslice = role[3:-1]

                    bindsetting = clientpath+"/settings/bindsetting.json"

                    myrole = discord.utils.get(ctx.guild.roles, id=int(roleslice))

                    try:
                        roleid = myrole.id 

                        with open(bindsetting) as f:
                            binddata = json.load(f)
                            f.close()

                        with open(logsetting) as f:
                            logdata = json.load(f)
                            f.close()

                        sslog = logdata["serversetuplog"]
                        
                        try:
                            findme = binddata[str(rankset)]
                            if roleid in findme:
                                findme.remove(roleid)

                                with open(bindsetting, "w") as f:
                                    json.dump(binddata, f, indent=2)
                                    f.close()

                                embed = discord.Embed(
                                    title = "성공 | 역할 제거",
                                    description = f"역할 {myrole.mention}을(를) 성공적으로 {rankset}에서 제거 했습니다.",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)

                                try:
                                    thischannel = await self.client.fetch_channel(sslog)

                                    embed = discord.Embed(
                                        title = "로그 | 역할설정 추가",
                                        description = f"명령어 사용자: {ctx.author.mention}\n역할순위: {rankset}\n역할: {myrole.mention}",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await thischannel.send(embed=embed)
                                except:
                                    pass

                            else:
                                findme.append(roleid)

                                with open(bindsetting, "w") as f:
                                    json.dump(binddata, f, indent=2)
                                    f.close()

                                embed = discord.Embed(
                                    title = "성공 | 역할설정 추가",
                                    description = f"역할 {myrole.mention}을(를) 성공적으로 {rankset}에 추가 했습니다",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)

                                try:
                                    thischannel = await self.client.fetch_channel(sslog)

                                    embed = discord.Embed(
                                        title = "로그 | 역할설정 제거",
                                        description = f"명령어 사용자: {ctx.author.mention}\n역할순위: {rankset}\n역할: {myrole.mention}",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await thischannel.send(embed=embed)
                                except:
                                    pass

                        except:
                            embed = discord.Embed(
                                title = "에러 | 순위 존재여부",
                                description = f"해당 순위 {rankset}이 존재하지 않습니다.\n옳바른 그룹, 그룹에 있는 순위인지 확인해주시고\n그룹 역할을 최근에 수정하셨다면 '!그룹업데이트'를 해주세요.\n```!그룹업데이트```",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)

                    except:
                        embed = discord.Embed(
                            title = "에러 | 역할 미제공",
                            description = f"설정할 역할을 멘션해주세요.",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)

                    
                    

            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
            
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["이름설정"])
    async def setname(self, ctx, rankset=None, *, nameformat=None):
        serverid = ctx.guild.id 
        checkexist =  f"client/{serverid}/exist.json"
        logsetting = f"client/{serverid}/settings/logsetting.json"
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            if os.path.isfile(checkexist):
                if rankset == None or nameformat == None:
                    embed = discord.Embed(
                        title = "에러 | 순위, 역할 미제공",
                        description = f"순위(숫자, 아래있는 사진 맨 아랫칸), 그리고 설정하고 싶으신 이름 약자를 언급해주세요.\n```!이름설정 순위(숫자) PVT(예시)```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    embed.set_image(url="https://i.gyazo.com/thumb/1200/59ce9c7b78d7df44990b7710580f890a-png.jpg")
                    await ctx.send(embed=embed)

                else:
                    serverid = ctx.guild.id
                    namepath = f"client/{serverid}/settings/nameformat.json"

                    with open(namepath) as f:
                        namedata = json.load(f)
                        f.close()

                    with open(logsetting) as f:
                        logdata = json.load(f)
                        f.close()

                    sslog = logdata["serversetuplog"]
                    
                    try:
                        tryfind = namedata[str(rankset)]

                        if len(tryfind) > 0:
                            for x in tryfind:
                                tryfind.remove(x)
                            
                            tryfind.append(nameformat)
                            
                            with open(namepath, "w") as f:
                                json.dump(namedata, f, indent=2)

                            embed = discord.Embed(
                                title = "성공 | 이름 설정 교체",
                                description = f"기존에 설정된 {x}를 제거하고 {rankset}의 약자를 {nameformat}으로 설정하였습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)

                            try:
                                thischannel = await self.client.fetch_channel(sslog)

                                embed = discord.Embed(
                                    title = "로그 | 이름설정 변경",
                                    description = f"명령어 사용자: {ctx.author.mention}\n역할순위: {rankset}\n이름: {nameformat}",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await thischannel.send(embed=embed)
                            except:
                                pass

                        else:
                            tryfind.append(nameformat)

                            with open(namepath, "w") as f:
                                json.dump(namedata, f, indent=2)

                            embed = discord.Embed(
                                title = "성공 | 이름 설정",
                                description = f"{rankset}의 약자를 {nameformat}으로 설정하였습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)

                            try:
                                thischannel = await self.client.fetch_channel(sslog)

                                embed = discord.Embed(
                                    title = "로그 | 이름설정 추가",
                                    description = f"명령어 사용자: {ctx.author.mention}\n역할순위: {rankset}\n이름: {nameformat}",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await thischannel.send(embed=embed)
                            except:
                                pass

                    except:
                        embed = discord.Embed(
                            title = "에러 | 순위 존재여부",
                            description = f"해당 순위 {rankset}이 존재하지 않습니다.\n옳바른 그룹, 그룹에 있는 순위인지 확인해주시고\n그룹 역할을 최근에 수정하셨다면 '!그룹업데이트'를 해주세요.\n```!그룹업데이트```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["이름형식"])
    async def nameformat(self, ctx, *, nameformat=None):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            serverid = ctx.guild.id
            checkexist =  f"client/{serverid}/exist.json"
            path = f"client/{serverid}/settings/nameset.json"
            placepath = f"server/groupbind/nameset.json"
            logsetting = f"client/{serverid}/settings/logsetting.json"
            if os.path.isfile(checkexist):
                if nameformat == None:
                    embed = discord.Embed(
                        title = "에러 | 형식 미제공",
                        description = f"보기를 참고하여 아랫 사진을 보고 맞춰주시면 되겠습니다.\n```1 - 인증된 로블록스 이름\n2 - !이름설정을 통해 생성한 약자\n3 - 일반 디스코드 이름```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    embed.set_image(url="https://i.gyazo.com/thumb/1200/74c3907a53876bfeec5529cb1d852f56-png.jpg")
                    await ctx.send(embed=embed)
                else:
                    result = ""
                    for x in nameformat:
                        if x == "1":
                            result += "로블록스이름"
                        elif x == "2":
                            result += "역할 약자"
                        elif x == "3":
                            result += "디스코드이름"
                        else:
                            result += x
                    
                    with open(placepath) as f:
                        data = json.load(f)
                        f.close()

                    with open(logsetting) as f:
                        logdata = json.load(f)
                        f.close()

                    sslog = logdata["serversetuplog"]

                    data["nameformat"] = nameformat

                    with open(path, "w") as f:
                        json.dump(data, f, indent=2)

                    embed = discord.Embed(
                        title = "성공 | 이름형식 설정",
                        description = f"{result}(으)로 설정이 완료됐습니다.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)

                    thischannel = await self.client.fetch_channel(sslog)

                    embed = discord.Embed(
                        title = "로그 | 이름형식 추가",
                        description = f"명령어 사용자: {ctx.author.mention}\n이름형식: {result}",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await thischannel.send(embed=embed)

            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["서브그룹연동"])
    async def subgroupbind(self, ctx, groupid=None, role=None):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            if groupid != None and role != None:
                serverid = ctx.guild.id
                checkexist =  f"client/{serverid}/exist.json"
                logsetting = f"client/{serverid}/settings/logsetting.json"
                if os.path.isfile(checkexist):
                    path = f"client/{serverid}/settings/bindsetting.json"

                    r = req.get(f"https://groups.roblox.com/v1/groups/{groupid}").json()

                    try: 
                        groupid = r["id"]
                        getroleid = role[3:-1]

                        myrole = discord.utils.get(ctx.guild.roles, id=int(getroleid))

                        try: 
                            roleid = myrole.id

                            with open(path) as f:
                                data = json.load(f)
                                f.close()

                            with open(logsetting) as f:
                                logdata = json.load(f)
                                f.close()

                            sslog = logdata["serversetuplog"]
                            
                            try:
                                getsub = data["subgroup"][str(groupid)]

                                if data["subgroup"][str(groupid)] == int(roleid):
                                    del data["subgroup"][str(groupid)]
                                else:
                                    getsub = None
                                    del data["subgroup"][str(groupid)]
                                    data["subgroup"][str(groupid)] = int(roleid) 


                            except:
                                getsub = None
                                data["subgroup"][str(groupid)] = int(roleid) 

                            with open(path, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()
                            

                            if getsub == None:
                                embed = discord.Embed(
                                    title = "성공 | 서브그룹 추가",
                                    description = f"그룹아이디({groupid})를 {myrole.mention}와(과) 연동 추가했습니다.",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)
                                try:
                                    thischannel = await self.client.fetch_channel(sslog)

                                    embed = discord.Embed(
                                        title = "로그 | 서브그룹 추가",
                                        description = f"명령어 사용자: {ctx.author.mention}\n그룹: {groupid}\n역할: {myrole.mention}",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await thischannel.send(embed=embed)
                                except:
                                    pass

                            else:
                                embed = discord.Embed(
                                    title = "성공 | 서브그룹 제거",
                                    description = f"그룹아이디({groupid})를 {myrole.mention}와(과) 연동 제거했습니다.",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed) 

                                try:
                                    thischannel = await self.client.fetch_channel(sslog)

                                    embed = discord.Embed(
                                        title = "로그 | 서브그룹 제거",
                                        description = f"명령어 사용자: {ctx.author.mention}\n그룹: {groupid}\n역할: {myrole.mention}",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await thischannel.send(embed=embed)
                                except:
                                    pass

                        except:
                            embed = discord.Embed(
                                title = "에러 | 역할 미제공",
                                description = f"연동할 역할을 멘션해주세요.",
                                color = discord.Color.from_rgb(255, 0, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)  

                    except:
                        embed = discord.Embed(
                            title = "에러 | 부정확한 그룹아이디",
                            description = f"해당 그룹이 존재하지 않습니다.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)  
                else:
                    embed = discord.Embed(
                        title = "에러 | 연동되지 않음",
                        description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 아이디, 역할 미제공",
                    description = f"연동할 타 그룹 아이디, 또는 역할을 멘션해주세요.\n```!서브그룹연동 그룹아이디 역할```",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["역할화리"])
    async def whitelist(self, ctx, role=None):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            serverid = ctx.guild.id
            checkexist =  f"client/{serverid}/exist.json"
            logsetting = f"client/{serverid}/settings/logsetting.json"
            if os.path.isfile(checkexist):

                if role != None:
                    getroleid = role[3:-1]

                    myrole = discord.utils.get(ctx.guild.roles, id=int(getroleid))

                    try:
                        roleid = myrole.id

                        bindsetting =  f"client/{serverid}/settings/bindsetting.json"

                        with open(bindsetting) as f:
                            data = json.load(f)
                            f.close()

                        with open(logsetting) as f:
                            logdata = json.load(f)
                            f.close()

                        sslog = logdata["serversetuplog"]

                        if int(getroleid) not in data["whitelisted"]:
                            data["whitelisted"].append(int(getroleid))

                            with open(bindsetting, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()

                            embed = discord.Embed(
                                title = "성공 | 화이트리스트 추가",
                                description = f"{myrole.mention}을(를) 성공적으로 화이트리스트 추가했습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)
                            try:
                                thischannel = await self.client.fetch_channel(sslog)

                                embed = discord.Embed(
                                    title = "로그 | 화이트리스트 추가",
                                    description = f"명령어 사용자: {ctx.author.mention}\n역할: {myrole.mention}",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await thischannel.send(embed=embed)
                            except:
                                pass


                        else:
                            data["whitelisted"].remove(int(getroleid))

                            with open(bindsetting, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()

                            embed = discord.Embed(
                                title = "성공 | 화이트리스트 제거",
                                description = f"{myrole.mention}을(를) 성공적으로 화이트리스트 제거했습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)
                            try:
                                thischannel = await self.client.fetch_channel(sslog)

                                embed = discord.Embed(
                                    title = "로그 | 화이트리스트 제거",
                                    description = f"명령어 사용자: {ctx.author.mention}\n역할: {myrole.mention}",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await thischannel.send(embed=embed)
                            except:
                                pass

                    except:
                        embed = discord.Embed(
                            title = "에러 | 역할 미제공",
                            description = f"연동할 역할을 멘션해주세요.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "에러 | 역할 미제공",
                        description = f"연동할 역할을 멘션해주세요.\n```!역할화리 @역할멘션```",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)  
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["초기화"])
    async def resetdata(self, ctx):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            serverid = ctx.guild.id
            checkexist =  f"client/{serverid}/exist.json"
            if os.path.isfile(checkexist):
                shutil.rmtree(f"client/{serverid}")

                embed = discord.Embed(
                    title = "성공 | 서버 초기화",
                    description = f"성공적으로 서버 데이터를 초기화했습니다.",
                    color = discord.Color.from_rgb(0, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)  

            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["그룹블랙"])
    async def groupblacklist(self, ctx, groupid=None):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            serverid = ctx.guild.id
            checkexist =  f"client/{serverid}/exist.json"
            desiredpath = f"client/{serverid}/settings/blacklist.json"
            logsetting = f"client/{serverid}/settings/logsetting.json"
            if os.path.isfile(checkexist):
                if groupid != None:
                    if os.path.isfile(desiredpath):
                        pass
                    else:
                        format = f"server/groupbind/blacklist.json"
                        with open(format) as f:
                            jsondata = json.load(f)
                            f.close()
                        
                        with open(desiredpath, "w") as f:
                            json.dump(jsondata, f, indent=2)
                            f.close()
                    
                    with open(desiredpath) as f:
                        jsondata = json.load(f)
                        f.close()

                    with open(logsetting) as f:
                        logdata = json.load(f)
                        f.close()

                    bllog = logdata["blacklistlog"]

                    if int(groupid) in jsondata["group"]:
                        jsondata["group"].remove(int(groupid))

                        with open(desiredpath, "w") as f:
                            json.dump(jsondata, f, indent=2)
                            f.close()

                        embed = discord.Embed(
                            title = "성공 | 그룹 블랙리스트 제거",
                            description = f"그룹({groupid})을 성공적으로 블랙리스트 제거했습니다.",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)

                        thischannel = await self.client.fetch_channel(bllog)

                        embed = discord.Embed(
                            title = "로그 | 그룹 블랙리스트 제거",
                            description = f"명령어 사용자: {ctx.author.mention}\n그룹아이디: {groupid}",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await thischannel.send(embed=embed)

                    else:
                        jsondata["group"].append(int(groupid))

                        with open(desiredpath, "w") as f:
                            json.dump(jsondata, f, indent=2)
                            f.close()

                        embed = discord.Embed(
                            title = "성공 | 그룹 블랙리스트 추가",
                            description = f"그룹({groupid})을 성공적으로 블랙리스트 추가했습니다.",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed) 

                        thischannel = await self.client.fetch_channel(bllog)

                        embed = discord.Embed(
                            title = "로그 | 그룹 블랙리스트 추가",
                            description = f"명령어 사용자: {ctx.author.mention}\n그룹아이디: {groupid}",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await thischannel.send(embed=embed)

                else:
                    embed = discord.Embed(
                        title = "에러 | 그룹아이디 미제공",
                        description = f"블랙리스트할 그룹 아이디를 입력해주세요.\n```!그룹블랙 그룹아이디```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)  
              
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["유저블랙"])
    async def userblacklist(self, ctx, username=None):
        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            serverid = ctx.guild.id
            checkexist =  f"client/{serverid}/exist.json"
            desiredpath = f"client/{serverid}/settings/blacklist.json"
            logsetting = f"client/{serverid}/settings/logsetting.json"
            if os.path.isfile(checkexist):
                if username != None:

                    r = req.get(f"https://api.roblox.com/users/get-by-username?username={username}").json()

                    try:
                        userid = r["Id"]
                    except:
                        userid = None
                    finally:
                        if userid != None:

                            if os.path.isfile(desiredpath):
                                pass
                            else:
                                format = f"server/groupbind/blacklist.json"
                                with open(format) as f:
                                    jsondata = json.load(f)
                                    f.close()
                                
                                with open(desiredpath, "w") as f:
                                    json.dump(jsondata, f, indent=2)
                                    f.close()
                            
                            with open(desiredpath) as f:
                                jsondata = json.load(f)
                                f.close()

                            with open(logsetting) as f:
                                logdata = json.load(f)
                                f.close()

                            bllog = logdata["blacklistlog"]

                            if int(userid) in jsondata["player"]:
                                jsondata["player"].remove(int(userid))

                                with open(desiredpath, "w") as f:
                                    json.dump(jsondata, f, indent=2)
                                    f.close()

                                embed = discord.Embed(
                                    title = "성공 | 유저 블랙리스트 제거",
                                    description = f"유저({username})을 성공적으로 블랙리스트 제거했습니다",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)  

                                thischannel = await self.client.fetch_channel(bllog)

                                embed = discord.Embed(
                                    title = "로그 | 유저 블랙리스트 제거",
                                    description = f"명령어 사용자: {ctx.author.mention}\n대상 유저: {username}({userid})",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await thischannel.send(embed=embed)

                            else:
                                jsondata["player"].append(int(userid))

                                with open(desiredpath, "w") as f:
                                    json.dump(jsondata, f, indent=2)
                                    f.close()

                                embed = discord.Embed(
                                    title = "성공 | 유저 블랙리스트 추가",
                                    description = f"유저({username})을 성공적으로 블랙리스트 추가했습니다",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed) 

                                thischannel = await self.client.fetch_channel(bllog)

                                embed = discord.Embed(
                                    title = "로그 | 유저 블랙리스트 추가",
                                    description = f"명령어 사용자: {ctx.author.mention}\n대상 유저: {username}({userid})",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await thischannel.send(embed=embed)

                        else:
                            embed = discord.Embed(
                                title = "에러 | 유저 존재여부",
                                description = f"{username}이라는 이름이 존재하지 않습니다.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)                      
                else:
                    embed = discord.Embed(
                        title = "에러 | 유저아이디 미제공",
                        description = f"블랙할 유저 아이디를 입력해주세요.\n```!유저블랙 유저아이디```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)  
              
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)
 
    


def setup(client):
    client.add_cog(verify(client))