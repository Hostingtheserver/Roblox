import discord
import os
import json
from discord.ext import commands
import requests
import random
from disputils import BotEmbedPaginator, BotConfirmation, BotMultipleChoice



class help(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command(aliases=["도움말"])
    async def help(self, ctx, whattype=None):
        helpdic = {
            #인증관련
            "봇구매" : "네스티코어 사용 화이트리스트를 구매합니다\n`!봇구매`",
            "인증" : "본인의 디스코드 계정과 로블록스 계정을 연동합니다\n`!인증`",
            "인증해제" : "본인의 디스코드 계정과 연동된 로블록스 계정을 연결 해제합니다\n`!인증해제`",
            "업데이트" : "본인, 또는 타인의 역할을 업데이트합니다\n`!업데이트`(본인), `!업데이트 <@유저멘션>(타인)`",
            "업데이트활성화" : "업데이트 명령어를 활성화시킵니다\n`!업데이트활성화`",
            "업데이트비활성화" : "업데이트 명령어를 비활성화시킵니다(그룹 설정도중)\n`!업데이트비활성화`",
            #그룹연동관련
            "그룹연동" : "해당 서버와 제공된 그룹 아이디를 연동합니다\n`!그룹연동 <그룹아이디>`",
            "그룹업데이트" : "그룹에 업데이트된 사항이 있을시(역할이름, 역할번호..등등) 그룹을 최신 상태로 업데이트\n`!그룹업데이트`",
            "그룹역할" : "연동된 그룹에 가입할시 줄 역할을 설정합니다(여러개 설정 가능)\n`!그룹역할 <@역할멘션>`",
            "역할설정" : "연동된 그룹에 대한 역할에 따라 부여할 역할을 설정합니다(여러개 설정 가능)\n`!역할설정 <역할순위> <@역할멘션>`",
            "이름설정" : "연동된 그룹에 대한 역할에 따라 부여할 약자(예시 - PVT, 어드민..등등)을 설정합니다(역할당 약자 하나)\n`!이름설정 <역할순위> <이름약자>`",
            "이름형식" : "유저가 업데이트를 할 시 이름형식을 설정합니다(자세한것은 `!이름형식`)\n`!이름형식 [2] 1`",
            "서브그룹연동" : "연동된 그룹이 **아닌** 타 그룹에 있을시 부여할 역할을 설정합니다(타 그룹 하나당 역할 하나)\n`!서브그룹연동 <타 그룹 아이디> <@역할멘션>`",
            "역할화리" : "유저가 업데이트를 할 시 연동되지 않은 역할은 모두 제거되지만 역할 화이트리스트를 추가하여 제거되지 않게합니다(다시 사용할시 화이트리스트 제거)\n`!역할화리 <@역할멘션>`",
            "초기화" : "이 서버에 연동/설정된 모든 데이터를 봇이 **영구적**으로 삭제합니다\n`!초기화`",
            "그룹블랙" : "그룹 블랙리스트를 추가하여 해당 그룹에 가입되어있는 유저는 업데이트를 못하게 합니다(다시 사용할시 블랙리스트 제거)\n`!그룹블랙 <그룹아이디>`",
            "유저블랙" : "유저 블랙리스트를 추가하여 해당 유저는 업데이트를 못하게 합니다(다시 사용할시 블랙리스트 제거)\n`!유저블랙 <로블록스 이름>`",
            #검색관련
            "유저검색" : "로블록스 유저를 이름을 통해 검색합니다\n`!유저검색 <로블록스이름>`",
            "유저정보" : "로블록스 유저를 인증된 디스코드 맴버 멘션을 통해 검색합니다\n`!유저정보 <@유저멘션>`",
            "그룹검색" : "로블록스 그룹을 그룹 아이디를 통해 검색합니다\n`!그룹검색 <그룹아이디>`",
            "그룹정보" : "서버와 연동된 로블록스 그룹에 대한 정보를 불러옵니다\n`!그룹정보`",
            #설정관련
            "설정확인" : "서버의 설정을 불러옵니다\n`!설정확인 <역할/이름/로그>(택1)`",
            "로그설정" : "로그 채널을 설정합니다\n`!로그설정 <프리미엄/블랙리스트/서버설정> <#채널멘션>`",
            #프리미엄명령어
            "프리미엄구매(점검중)" : "프리미엄 구매 절차를 돕습니다.\n`!프리미엄구매`",
            "제품등록" : "프리미엄을 구매할때 주어진 제품 키를 등록하는 명령어입니다.\n`!제품등록 <제품키>`",
            "프리미엄설정" : "새롭게 디자인된 명령어로써 프리미엄의 실질적으로 모든것을 설정하게 도와줍니다\n`!프리미엄설정`",
            "샤우트" : "그룹 샤우트를 등록합니다\n`!샤우트 <메세지>`",
            "진급" : "유저의 그룹 역할을 *한단계* 위로 올립니다\n`!진급 <로블록스 이름>`",
            "강등" : "유저의 그룹 역할을 *한단계* 내립니다\n`!강등 <로블록스 이름>`",
            "역할변경" : "유저의 역할을 역할순위를 사용하여 변경합니다\n`!역할변경 <로블록스이름> <역할순위(숫자)>`",
            "그룹수락" : "가입 승인대기중인 유저를 승인합니다\n`!수락 <로블록스 이름>`",
            "그룹추방" : "유저를 로블록스 그룹에서 추방합니다\n`!추방 <로블록스 이름>`",
        }

        if whattype == None:
            embed = discord.Embed(
                title = f"도움말 안내",
                description = f"아래 목록에서 더 자세히 보고싶은 명령어가 있다면, `!도움말 <명령어이름>`을 사용해주세요.",
                color = discord.Color.from_rgb(0, 83, 185)
            )
            embed.add_field(name="인증 관련", value="`봇구매`, `인증`, `인증해제`, `업데이트`, `업데이트활성화`, `업데이트비활성화`", inline=False)
            embed.add_field(name="그룹 연동 관련", value="`그룹연동`, `그룹업데이트`, `그룹역할`, `역할설정`, `이름설정`, `이름형식`, `서브그룹연동`, `역할화리`, `초기화`, `유저블랙`, `그룹블랙`", inline=False)
            embed.add_field(name="검색 관련", value="`유저검색`, `유저정보`, `그룹검색`, `그룹정보`", inline=False)
            embed.add_field(name="설정 관련", value="`설정확인`, `로그설정`", inline=False)
            embed.add_field(name="프리미엄 명령어", value="`프리미엄구매`, `제품등록`, `프리미엄설정`, `샤우트`, `진급`, `강등`, `역할변경`, `그룹수락`, `그룹추방`", inline=False)
            embed.add_field(name="공식 지원 서버", value="🔗[공식 디스코드 서버 링크](https://discord.gg/6RkVxYQFP2)\n봇에 대한 질문, 버그신고, 지원이 필요하다면 위 서버를 가입해주세요\n\n🤖[디스코드 봇 초대링크](https://discord.com/oauth2/authorize?client_id=792968755679854602&scope=bot&permissions=8)", inline=False)
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)
        else:
            try:
                koreandesc = helpdic[whattype]

                embed = discord.Embed(
                    title = f"도움말 {whattype}",
                    description = f"{koreandesc}",
                    color = discord.Color.from_rgb(0, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

            except:
                embed = discord.Embed(
                    title = f"도움말 찾기 실패",
                    description = f"해당 명령어 `{whattype}`을 찾을수 없었습니다.\n`!도움말` 명령어를 통해 제공된 목록중 하나를 선택해주세요.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)


def setup(client):
    client.add_cog(help(client))