import discord
from discord.ext import tasks, commands
import os 
import json
import asyncio

class On_Ready(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.startwork.start()
        #self.changestatusmessage.start()

    @tasks.loop()
    async def changestatusmessage(self):
        while True:
            game = discord.Game(name = "!도움말 | 로블록스 한글 인증/서버관리봇")
            await self.client.change_presence(activity = game)

            await asyncio.sleep(10)

            dbpath = "server/verificationdb/db"
            svpath = "client"

            dbnumber = len(os.listdir(dbpath))
            svnumber = len(os.listdir(svpath))

            await self.client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f"{dbnumber}개의 인증 데이터 | {svnumber}개의 서버 데이터"))

            await asyncio.sleep(10)

    @commands.Cog.listener()
    async def on_ready(self):
        game = discord.Game(name = "!도움말 | 로블록스 한글 인증/서버관리봇")
        await self.client.change_presence(activity = game)
        print("I am ready!")

    @tasks.loop(seconds=30)
    async def startwork(self):
        for filename in os.listdir("server/checkdone"):
            os.remove(f"server/checkdone/{filename}")

'''
    @commands.Cog.listener()
    async def on_message(self, ctx):
        if ctx.author.bot == False:
            if ctx.author.id != ctx.guild.owner_id:
                serverid = ctx.guild.id
                if os.path.isfile(mypath+f"/client/{serverid}/exist.json"):

                    with open(mypath+f"/client/{serverid}/settings/basicsetting.json") as f:
                        data = json.load(f)
                        f.close()

                    if data["autocheck"] == True:

                        bypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                        if bypass not in ctx.author.roles:

                            userid = ctx.author.id
                            if os.path.isfile(mypath+f"/server/checkdone/{userid}.json"):
                                return

                            else:
                                if os.path.isfile(mypath+f"/server/verificationdb/db/{userid}.json"):
                                    return

                                else:
                                    thislist = []
                                    
                                    result = "제거된 역할"

                                    for x in ctx.author.roles:
                                        thislist.append(x.name)
                                    
                                    for x in thislist:
                                        role = discord.utils.get(ctx.guild.roles, name=x)
                                        try:
                                            await ctx.author.remove_roles(role)
                                            result += f"\n-{role.mention}"
                                        except:
                                            continue
                                    
                                    if result == "제거된 역할":
                                        with open(mypath+f"/server/checkdone/{userid}.json", "w") as f:
                                            f.close()
                                        return
                                    else:
                                        with open(mypath+f"/server/checkdone/{userid}.json", "w") as f:
                                            f.close()
                                        embed = discord.Embed(
                                            title = f"역할 제거 완료(비인증 유저 자동감지)",
                                            description = f"{ctx.author.mention}\n{result}\n*이 가능은 서버 주인이 !setting 명령어를 이용해 끌 수 있습니다*",
                                            color = discord.Color.from_rgb(0, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.channel.send(embed=embed)
'''

def setup(client):
    client.add_cog(On_Ready(client))