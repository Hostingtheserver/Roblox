import discord
import os
import json
from discord.ext import commands
import requests
import random

req = requests.Session()
#verify, unverify mypath -> vpspath

def getcommand(ctx):
    splitlist = ctx.split(" ")[0]
    return splitlist

class owner(commands.Cog):

    def __init__(self, client):
        self.client = client
    
    @commands.command()
    async def getinfo(self, ctx):
        newlist = []
        if ctx.author.id == 631441731350691850:
            for x in self.client.guilds:
                await ctx.author.send(f"{x.name, x.member_count}")
    
    @commands.command()
    async def ownertestme(self, ctx, what=None):
        await ctx.send(getcommand(ctx.message.content))
    

def setup(client):
    client.add_cog(owner(client))