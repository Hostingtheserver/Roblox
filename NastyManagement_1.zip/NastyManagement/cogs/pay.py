import discord
import os
import json
from discord.ext import commands
from discord.ext.commands.core import check
import requests
import random
import asyncio

ownerid = 631441731350691850
mainserverid = 792306366906630154
secretchannel = 818103500021956648



custompath = "server/regulardb"
verifypath = "server/verificationdb/db"

req = requests.Session()
req.cookies[".ROBLOSECURITY"] = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_8968E2E9296BEE204B958247DCD11619BF2EBB60B728E0220FB4E020B35810EED1EB7D12E89B1B09D42375159EF1C01101B672BED6A74004B673882CE11F9F5C0EC0CA7E5458A4602EAAE902E4E273964721B326F8DADB671338EE987748474D02A76AFDA1C6B1B0EF7B6B48080D1215EDC0669A732ADBB016CCF760C803DCD8396CACAC6FBA10D82230F52227F4376459621AAFF5819C6A05ADBB4B5573201E6C68ABC591E39ABF58E01C68CDC5E5A57BD084AE25338655EAD659E351F784F10C30C803EA740402552EDA9DB01D9BBF91547B81249E546A211FF47C2310F93353F2972866DBAE8E0F26563B50DC0D48459130A9FDE287E63590223852B9980BB632C4D4FE8C32E26DB9285D56101FC9EAB0D20FB32228C4F84F36DED8BD02CA59C8C2DFBB33CCAAD5DD654120B8EEC7C8698B67"

###############################################################
def checkregular(serverid):
    if os.path.isfile(custompath + f"/{serverid}.txt"):
        return True
    else:
        return False

'''
#1, 2선택
def firstcheck(reaction, user):
    return reaction.message.id == original.id and str(reaction.emoji) in onetwo and user == ctx.author

#대답
def chatcheck(author):
    def inner_check(message):
        return message.author.id == author
    return inner_check
'''
################################################################
    
class pay(commands.Cog):

    def __init__(self, client):
        self.client = client
    """
    @commands.command(aliases=["프리미엄구매"])
    async def premiumpurchase(self, ctx):
        buyfail = discord.utils.get(self.client.get_all_channels(), id = 829262100211040277)
        buysuccess = discord.utils.get(self.client.get_all_channels(), id = 829261961724297217)
        authorid = ctx.author.id
        if isinstance(ctx.channel, discord.channel.DMChannel):

            shirtid = 6649169989
            loadingemoji = "<a:loading:792942564323885067>"
            checkemoji = "<a:movingcheck:828898622916526120>"
            xemoji = "❌"
            descresult = f"{loadingemoji} 인증데이터 확인중"

            embed = discord.Embed(
                title = "구매 | 조건 충족 확인중",
                description = descresult,
                color = discord.Color.from_rgb(0, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            embed1 = await ctx.send(embed=embed)

            if os.path.isfile(verifypath + f"/{authorid}.json"):


                with open(verifypath + f"/{authorid}.json") as f:
                    jsondata = json.load(f)
                    f.close()

                userid = jsondata["robloxid"]

                r = req.get(f"https://api.roblox.com/users/{userid}").json()
                username = r["Username"]

                descresult = f"{checkemoji} 인증데이터 확인완료({username})\n\n{loadingemoji} 인벤토리 설정 확인중"

                embed = discord.Embed(
                    title = "구매 | 조건 충족 확인중",
                    description = descresult,
                    color = discord.Color.from_rgb(0, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await embed1.edit(embed=embed)

                r = req.get(f"https://inventory.roblox.com/v1/users/{userid}/can-view-inventory").json()

                if r["canView"] == True:

                    descresult = f"{checkemoji} 인증데이터 확인완료({username})\n\n{checkemoji} 인벤토리 공개로 설정필요\n\n{loadingemoji} 셔츠 구매여부 확인중"

                    embed = discord.Embed(
                        title = "구매 | 조건 충족 확인중",
                        description = descresult,
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await embed1.edit(embed=embed)

                    r = req.get(f"https://inventory.roblox.com/v1/users/{userid}/items/Asset/{shirtid}").json()
                    ownshirtbefore = False
                    try:
                        r["data"][0]["id"]
                        ownshirtbefore = True
                    except:
                        pass
                    finally:
                        if ownshirtbefore == False:

                            reactionlist = ["<a:movingcheck:828898622916526120>", "❌"]

                            await embed1.delete()

                            embed = discord.Embed(
                                title = "구매 | 조건 충족",
                                description = f"{username} 계정으로 [셔츠](https://www.roblox.com/catalog/{shirtid})를 구매해주세요.\n5분이라는 시간이 주어지며 제한시간안에 반응이 없을시 프로세스가 종료됩니다.\n문제가 생길시 [지원서버](https://discord.gg/6RkVxYQFP2)에 오셔서 주인에게 개인 채팅을 보내주세요.\n구매 하셨으면 체크, 프로세스를 종료하려면 X를 눌러주세요.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            purchaseprompt = await ctx.send(embed=embed)
                            
                            for i in reactionlist:
                                await purchaseprompt.add_reaction(i)

                            def firstcheck(reaction, user):
                                return reaction.message.id == purchaseprompt.id and str(reaction.emoji) in reactionlist and user == ctx.author

                            try:
                                reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 300)

                                if reaction.emoji == "❌":

                                    fail = discord.Embed(
                                        title = "취소 | 프로세스",
                                        description = f"프로세스가 취소되었습니다.",
                                        color = discord.Color.from_rgb(255, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await purchaseprompt.edit(embed=fail)
                                else:
                                    r = req.get(f"https://inventory.roblox.com/v1/users/{userid}/items/Asset/{shirtid}").json()
                                    purchased = False
                                    try:
                                        r["data"][0]["id"]
                                        purchased = True
                                    except:
                                        purchased = False
                                    
                                    if purchased == True:
                                        keylist = [
                                            "A",
                                            "B",
                                            "C",
                                            "D",
                                            "E",
                                            "F",
                                            "G",
                                            "H",
                                            "I"
                                            "J",
                                            "a",
                                            "b",
                                            "c",
                                            "d",
                                            "e",
                                            "f",
                                            "g",
                                            "h",
                                            "i",
                                            "0",
                                            "1",
                                            "48",
                                            "29",
                                            "19",
                                            "key"
                                        ]

                                        limit = 15
                                        i = 0
                                        result = "nc-"

                                        while i < limit:
                                            randomnumber = random.randint(1, 23)
                                            word = keylist[randomnumber]
                                            result = result + word
                                            i += 1
                                        
                                        if os.path.isfile(custompath+f"/key/{result}.txt"):
                                            embed = discord.Embed(
                                                title = "치명적인 에러",
                                                description = "명령어 재사용해주세요.",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                        else:
                                            with open(custompath+f"/key/{result}.txt", "w") as f:
                                                f.close()

                                            embed = discord.Embed(
                                                title = "프리미엄 활성화 코드",
                                                description = f"프리미엄 활성화 코드가 생성되었습니다. 이 코드를 사용하려면 본인 서버에 가서 `!제품등록 코드` 명령어를 사용해주세요.\n코드 삭제까지 기간은 없으나 실수로 유출 시 모든 책임은 구매자에게 있습니다.\n제품코드:\n```{result}```",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await purchaseprompt.edit(embed=embed)
                                            await buysuccess.send(f"아이디: {ctx.author.id}\n정보: {ctx.author.name}#{ctx.author.discriminator}\n코드: {result}")

                                    else:
                                        fail = discord.Embed(
                                            title = "에러 | 구매하지않음",
                                            description = f"안내된 셔츠를 구매하지 않으셨습니다. 구매하셨는데 봇의 오류라면 [지원서버](https://discord.gg/6RkVxYQFP2)에 오셔서 N A S T Y#7777에게 개인 채팅을 보내주세요.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await purchaseprompt.edit(embed=fail)
                                        await buyfail.send(f"아이디: {ctx.author.id}\n정보: {ctx.author.name}#{ctx.author.discriminator}")

                            except asyncio.exceptions.TimeoutError:
                                await ctx.send("5분이 지나 프로세스가 종료되었습니다.")

                        else:
                            descresult = f"{checkemoji} 인증데이터 확인완료({username})\n\n{checkemoji} 인벤토리 공개로 설정필요\n\n{xemoji} 셔츠 이미 보유중(셔츠를 인벤토리에서 지우고 명령어 재실행해주세요.)"

                            embed = discord.Embed(
                                title = "에러 | 셔츠 이미 보유중",
                                description = descresult,
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await embed1.edit(embed=embed)


                else:

                    descresult = f"{checkemoji} 인증데이터 확인완료({username})\n\n{xemoji} 인벤토리 공개로 설정필요"

                    embed = discord.Embed(
                        title = "에러 | 인벤토리 확인불가",
                        description = descresult,
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await embed1.edit(embed=embed)

            else:
                descresult = f"{xemoji} 인증필요"

                embed = discord.Embed(
                    title = "에러 | 인증안됨",
                    description = descresult,
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await embed1.edit(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 개인 채팅에서 사용해주세요",
                description = "이 명령어는 개인 채팅을 통해 사용해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)   
    """
    @commands.command(aliases=["봇구매"])
    async def botpurchase(self, ctx):
        if isinstance(ctx.channel, discord.channel.DMChannel):
            purchaseadviceprompt = discord.Embed(
                title = "구매 방법",
                description = f"<:bobux:799596446855725057> 로벅스: 1,000 Robux,\n<:cultureland:829254798577631243> 문화상품권: ₩5,000\n<:toss:879560224258805780> 계좌: ₩4,000\n```한 번의 구매는 서버 하나의 네스티코어 평생(서비스 유지 기간동안) 이용을 보증합니다```\n구매 방법: https://discord.gg/jsfxCgDMye 가입 후 설명 확인",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            purchaseadviceprompt.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=purchaseadviceprompt)
        else:
            embed = discord.Embed(
                title = "에러 | 개인채팅 아님",
                description = f"이 명령어는 개인채팅에서 사용 부탁드립니다!",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["서버화리"])
    async def swhitelist(self, ctx, serverid=None):
        if ctx.author.id == ownerid and serverid != None:
            if checkregular(serverid):
                await ctx.send("Already Whitelisted.")
            else:
                with open(custompath+f"/{serverid}.txt", "w") as f:
                    f.close()
                await ctx.send("OK!")


def setup(client):
    client.add_cog(pay(client)) 