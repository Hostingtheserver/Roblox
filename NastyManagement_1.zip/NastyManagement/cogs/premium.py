import discord
import os
import json
from discord.ext import commands
from discord.ext.commands.core import check
import requests
import random
import asyncio

ownerid = 631441731350691850
mainserverid = 792306366906630154
secretchannel = 818103500021956648



custompath = "server/premiumdb"
verifypath = "server/verificationdb/db"

req = requests.Session()
req.cookies[".ROBLOSECURITY"] = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_8968E2E9296BEE204B958247DCD11619BF2EBB60B728E0220FB4E020B35810EED1EB7D12E89B1B09D42375159EF1C01101B672BED6A74004B673882CE11F9F5C0EC0CA7E5458A4602EAAE902E4E273964721B326F8DADB671338EE987748474D02A76AFDA1C6B1B0EF7B6B48080D1215EDC0669A732ADBB016CCF760C803DCD8396CACAC6FBA10D82230F52227F4376459621AAFF5819C6A05ADBB4B5573201E6C68ABC591E39ABF58E01C68CDC5E5A57BD084AE25338655EAD659E351F784F10C30C803EA740402552EDA9DB01D9BBF91547B81249E546A211FF47C2310F93353F2972866DBAE8E0F26563B50DC0D48459130A9FDE287E63590223852B9980BB632C4D4FE8C32E26DB9285D56101FC9EAB0D20FB32228C4F84F36DED8BD02CA59C8C2DFBB33CCAAD5DD654120B8EEC7C8698B67"

###############################################################
def checkpremium(serverid):
    if os.path.isfile(custompath + f"/time/{serverid}.txt"):
        return True
    else:
        return False

def checkowner(bownerid, userid):
    if userid == bownerid or userid == ownerid:
        return True
    else:
        return False

def checkkey(key):
    path1 = custompath + f"/key/{key}.txt"
    if os.path.isfile(path1):
        os.remove(path1)
        return True
    else:
        return False

def chatcheck(author):
    def inner_check(message):
        return message.author.id == author
    return inner_check

def groupowner(userid, groupid):
    r = req.get(f"https://groups.roblox.com/v1/groups/{groupid}").json()

    ownerid = r["owner"]["userId"]
    if ownerid == userid:
        return True
    else:
        return False

'''
#1, 2선택
def firstcheck(reaction, user):
    return reaction.message.id == original.id and str(reaction.emoji) in onetwo and user == ctx.author

#대답
def chatcheck(author):
    def inner_check(message):
        return message.author.id == author
    return inner_check
'''
################################################################
    
class premium(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command(aliases=["키전송", "코드전송"])
    async def sendkey(self, ctx, target:discord.Member):
        if ctx.author.id == ownerid and ctx.guild.id == mainserverid:
            buysuccess = discord.utils.get(self.client.get_all_channels(), id = 829261961724297217)
            keylist = [
                "A",
                "B",
                "C",
                "D",
                "E",
                "F",
                "G",
                "H",
                "I"
                "J",
                "a",
                "b",
                "c",
                "d",
                "e",
                "f",
                "g",
                "h",
                "i",
                "0",
                "1",
                "48",
                "29",
                "19",
                "key"
            ]

            limit = 15
            i = 0
            result = "nc-"

            while i < limit:
                randomnumber = random.randint(1, 23)
                word = keylist[randomnumber]
                result = result + word
                i += 1
            
            if os.path.isfile(custompath+f"/key/{result}.txt"):
                embed = discord.Embed(
                    title = "치명적인 에러",
                    description = "명령어 재사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
            else:
                with open(custompath+f"/key/{result}.txt", "w") as f:
                    f.close()
            
                try:
                    embed = discord.Embed(
                        title = "성공 | 코드 생성",
                        description = "성공적으로 생성된 코드를 전송하였습니다.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)

                    embed = discord.Embed(
                        title = "프리미엄 활성화 코드",
                        description = f"프리미엄 활성화 코드가 생성되었습니다. 이 코드를 사용하려면 본인 서버에 가서 `!제품등록 코드` 명령어를 사용해주세요.\n코드 삭제까지 기간은 없으나 실수로 유출 시 모든 책임은 구매자에게 있습니다.\n제품코드:\n```{result}```",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await target.send(embed=embed)

                    await buysuccess.send(f"아이디: {target.id}\n정보: {target.name}#{target.discriminator}")

                except:
                    embed = discord.Embed(
                        title = "실패 | 개인채팅 전송오류",
                        description = "해당 유저에게 개인 채팅을 열어달라고 부탁하십시오.",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)

        else:
            await ctx.send("no")
    
    @commands.command(aliases=["제품등록", "코드등록"])
    async def redeemkey(self, ctx, key=None):
        redeem = discord.utils.get(self.client.get_all_channels(), id = 829261889165983775)
        authorid = ctx.author.id
        serverid = ctx.guild.id
        if key != None:
            checkexist =  f"client/{serverid}/exist.json"
            if os.path.isfile(checkexist):
                if checkowner(ctx.guild.owner_id, ctx.author.id):
                    if checkpremium(serverid):
                        embed = discord.Embed(
                            title = "에러 | 프리미엄 서버",
                            description = f"해당 서버는 프리미엄을 이미 보유중입니다. 코드를 친구에게 선물해보세요!",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)          
                    else:
                        if os.path.isfile(verifypath+f"/{authorid}.json"):
                            if checkkey(key):
                                with open(verifypath+f"/{authorid}.json") as f:
                                    jsondata = json.load(f)
                                    f.close()
                                
                                userid = jsondata["robloxid"]

                                embed = discord.Embed(
                                    title = "<a:loading:792942564323885067> | 데이터베이스 등록중",
                                    description = f"잠시만 기다려주세요",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                loading = await ctx.send(embed=embed)

                                path1 = f"client/{serverid}/settings/basicsetting.json"

                                with open(path1) as f:
                                    jsondata = json.load(f)
                                    f.close()
                                
                                robloxid = jsondata["groupid"]



                                with open(custompath+"/format.json") as f:
                                    jsondata = json.load(f)
                                    f.close()
                                
                                jsondata["groupid"] = robloxid
                                jsondata["serverid"] = serverid

                                if groupowner(userid, robloxid):

                                    with open(custompath + f"/time/{serverid}.txt", "w") as f:
                                        f.close()
                                    
                                    with open(custompath + f"/setting/{serverid}.json", "w") as f:
                                        json.dump(jsondata, f, indent=2)
                                        f.close()

                                    embed = discord.Embed(
                                        title = "성공 | 코드등록",
                                        description = f"네스티코어 프리미엄 등록을 축하드립니다!",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await loading.edit(embed=embed)

                                    await redeem.send(f"아이디: {ctx.author.id}\n정보: {ctx.author.name}#{ctx.author.discriminator}\n코드: {key}\n서버아이디: {ctx.guild.id}\n서버이름: {ctx.guild.name}")

                                else:

                                    with open(custompath + f"/key/{key}.txt", "w") as f:
                                        f.close()

                                    embed = discord.Embed(
                                        title = "실패 | 그룹주인이 아님",
                                        description = f"프리미엄 악용을 방지하기 위해서 본인이 인증된 계정의 주인인 그룹만 프리미엄 적용 가능합니다.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await loading.edit(embed=embed)                
                            else:
                                embed = discord.Embed(
                                    title = "에러 | 존재하지 않는 코드",
                                    description = f"보내신 키 `{key}`는 존재하지 않습니다\n대소문자 유의해주세요.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)  

                        else:
                            embed = discord.Embed(
                                title = "실패 | 인증필요",
                                description = f"인증이 안된 상태입니다. 인증을 해주세요.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed) 
                else:
                    embed = discord.Embed(
                        title = "에러 | 권한오류",
                        description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 코드 미제공",
                description = f"등록할 제품의 코드를 입력해주세요.\n```!제품등록 코드```",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["프리미엄설정"])
    async def premiumsetting(self, ctx):
        serverid = ctx.guild.id
        checkexist =  f"client/{serverid}/exist.json"
        if os.path.isfile(checkexist):
            if checkowner(ctx.guild.owner_id, ctx.author.id):
                if checkpremium(serverid):
                    onetwo = ["🤖", "1️⃣", "2️⃣"]
                    yesno = ["⭕", "❌"]
                    robloxrole = ["⚙️", "🔒", "🔓", "🛑"]
                    discordrole = ["⚙️", "🗒️", "🔑"]
                    
                    embed = discord.Embed(
                        title = "선택 | 프리미엄 설정",
                        description = f"🤖 - 봇 그룹에 추가\n1️⃣ - 로블록스 역할 설정\n2️⃣ - 디스코드 권한 설정",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    prompt = await ctx.send(embed=embed)

                    for i in onetwo:
                        await prompt.add_reaction(i)

                    def chatcheck(author):
                        def inner_check(message):
                            return message.author.id == author
                        return inner_check

                    def firstcheck(reaction, user):
                        return reaction.message.id == prompt.id and str(reaction.emoji) in onetwo and user == ctx.author
                    
                    try:
                        reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 15)

                        await prompt.clear_reactions()

                        if reaction.emoji == "🤖":
                            botuserid = 1880765765
                            serverid = ctx.guild.id
                            with open(custompath + f"/setting/{serverid}.json") as f:
                                jsondata = json.load(f)
                                f.close()
                            
                            groupid = jsondata["groupid"]

                            r = req.get(f"https://groups.roblox.com/v1/users/{botuserid}/groups/roles").json()

                            hit = False
                            for i in r["data"]:
                                ingroupid = i["group"]["id"]
                                if groupid == ingroupid:
                                    hit = True
                                    break
                            
                            if hit == True:
                                embed = discord.Embed(
                                    title = "실패 | 이미 그룹에 있음",
                                    description = "봇(NastyCore_BOT)이 이미 그룹에 가입된 상태입니다.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await prompt.edit(embed=embed)
                            else:
                                embed = discord.Embed(
                                    title = "초대 | 봇",
                                    description = "프리미엄의 보안을 위해서 [네스티코어 제작서버](https://discord.gg/6RkVxYQFP2)에 가입해주시고 주인(N A S T Y#7777)에게 봇 초대를 요청해주세요.",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await prompt.edit(embed=embed)

                        elif reaction.emoji == "1️⃣":
                            embed = discord.Embed(
                                title = "선택 | 로블록스 역할 설정",
                                description = f"⚙️ - 설정 확인\n🔒 - 역할 잠금\n🔓 - 역할 잠금 해제\n🛑 - 최대 변경 가능 역할 설정",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await prompt.edit(embed=embed)

                            for i in robloxrole:
                                await prompt.add_reaction(i)

                            def firstcheck(reaction, user):
                                return reaction.message.id == prompt.id and str(reaction.emoji) in robloxrole and user == ctx.author
                            
                            try:
                                reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 60.0)

                                await prompt.clear_reactions()

                                if reaction.emoji == "⚙️":
                                    serverid = ctx.guild.id
                                    with open(custompath + f"/setting/{serverid}.json") as f:
                                        jsondata = json.load(f)
                                        f.close()
                                    
                                    groupid = jsondata["groupid"]
                                    locklist = list(jsondata["lockid"])
                                    stophere = jsondata["stophere"]

                                    r = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()
                                    result = ""

                                    for i in r["roles"]:
                                        rankname = i["name"]
                                        rankset = i["rank"]
                                        what = f"[{rankset}] - {rankname}"
                                        if rankset in locklist:
                                            rankset = str(rankset)
                                            what = f"{what}🔒"
                                        if rankset == stophere:
                                            what = f"{what}🛑"

                                        result = result + what + "\n"

                                    embed = discord.Embed(
                                        title = "확인 | 로블록스 역할설정",
                                        description = f"🔒 - 잠금역할(역할 변경할때 이 역할은 뛰어넘음)\n🛑 - 이 이상의 역할로는 진급안됨\n```{result}```",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)
                                    

                                elif reaction.emoji == "🔒":
                                    embed = discord.Embed(
                                        title = "선택 | 잠금할 역할순위",
                                        description = f"잠금하고 싶은 역할순위 하나를 **숫자만** 입력해주세요.",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    lockunlock = await ctx.send(embed=embed)

                                    def chatcheck(author):
                                        def inner_check(message):
                                            return message.author.id == author
                                        return inner_check

                                    try:
                                        msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 30.0)

                                        rankset = msg.content

                                        try:
                                            int(rankset)
                                            serverid = ctx.guild.id
                                            with open(custompath + f"/setting/{serverid}.json") as f:
                                                jsondata = json.load(f)
                                                f.close()

                                            if int(rankset) in jsondata["lockid"]:
                                                embed = discord.Embed(
                                                    title = "에러 | 잠금상태",
                                                    description = "해당 역할순위는 이미 잠금된 상태입니다.",
                                                    color = discord.Color.from_rgb(255, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await lockunlock.edit(embed=embed)
                                            else:
                                                jsondata["lockid"].append(int(rankset))

                                                with open(custompath + f"/setting/{serverid}.json", "w") as f:
                                                    json.dump(jsondata, f, indent=2)
                                                    f.close()

                                                embed = discord.Embed(
                                                    title = "성공 | 역할잠금",
                                                    description = "해당 역할순위를 잠궜습니다.",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await lockunlock.edit(embed=embed)

                                        except:
                                            embed = discord.Embed(
                                                title = "에러 | 올바르지 않은 역할순위",
                                                description = "역할순위(숫자)를 입력해주세요.",
                                                color = discord.Color.from_rgb(255, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await lockunlock.edit(embed=embed)

                                    except asyncio.exceptions.TimeoutError:
                                        embed = discord.Embed(
                                            title = "프로세스 종료",
                                            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await lockunlock.edit(embed=embed)

                                elif reaction.emoji == "🔓":
                                    embed = discord.Embed(
                                        title = "선택 | 잠금해제할 역할순위",
                                        description = f"잠금해제하고 싶은 역할순위 하나를 **숫자만** 입력해주세요.",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    lockunlock = await ctx.send(embed=embed)

                                    def chatcheck(author):
                                        def inner_check(message):
                                            return message.author.id == author
                                        return inner_check

                                    try:
                                        msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 30.0)

                                        rankset = msg.content

                                        try:
                                            int(rankset)
                                            serverid = ctx.guild.id
                                            with open(custompath + f"/setting/{serverid}.json") as f:
                                                jsondata = json.load(f)
                                                f.close()

                                            if int(rankset) not in jsondata["lockid"]:
                                                embed = discord.Embed(
                                                    title = "에러 | 잠금해제상태",
                                                    description = "해당 역할순위는 이미 잠금해제된 상태입니다.",
                                                    color = discord.Color.from_rgb(255, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await lockunlock.edit(embed=embed)
                                            else:
                                                jsondata["lockid"].remove(int(rankset))

                                                with open(custompath + f"/setting/{serverid}.json", "w") as f:
                                                    json.dump(jsondata, f, indent=2)
                                                    f.close()

                                                embed = discord.Embed(
                                                    title = "성공 | 역할잠금해제",
                                                    description = "해당 역할순위를 잠금해제하였습니다.",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await lockunlock.edit(embed=embed)

                                        except:
                                            embed = discord.Embed(
                                                title = "에러 | 올바르지 않은 역할순위",
                                                description = "역할순위(숫자)를 입력해주세요.",
                                                color = discord.Color.from_rgb(255, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await lockunlock.edit(embed=embed)

                                    except asyncio.exceptions.TimeoutError:
                                        embed = discord.Embed(
                                            title = "프로세스 종료",
                                            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await lockunlock.edit(embed=embed)
                                else:
                                    embed = discord.Embed(
                                        title = "선택 | 최대 변경 가능 역할",
                                        description = f"최대 변경 가능 역할로 설정할 역할순위 하나를 **숫자로** 입력해주세요.",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    lockunlock = await ctx.send(embed=embed)

                                    def chatcheck(author):
                                        def inner_check(message):
                                            return message.author.id == author
                                        return inner_check

                                    try:
                                        msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 30.0)

                                        rankset = msg.content

                                        try:
                                            int(rankset)
                                            serverid = ctx.guild.id
                                            with open(custompath + f"/setting/{serverid}.json") as f:
                                                jsondata = json.load(f)
                                                f.close()

                                            stopped = jsondata["stophere"]
                                            
                                            jsondata["stophere"] = int(rankset)

                                            with open(custompath + f"/setting/{serverid}.json", "w") as f:
                                                json.dump(jsondata, f, indent=2)
                                                f.close()

                                            if stopped == None:
                                                embed = discord.Embed(
                                                    title = "성공 | 최대 진급 가능 역할",
                                                    description = f"{rankset}으로 설정했습니다",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await lockunlock.edit(embed=embed)
                                            else:
                                                embed = discord.Embed(
                                                    title = "성공 | 최대 진급 가능 역할",
                                                    description = f"{stopped} -> {rankset}으로 설정했습니다",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await lockunlock.edit(embed=embed)                                                    

                                        except:
                                            embed = discord.Embed(
                                                title = "에러 | 올바르지 않은 역할순위",
                                                description = "역할순위(숫자)를 입력해주세요.",
                                                color = discord.Color.from_rgb(255, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await lockunlock.edit(embed=embed)

                                    except asyncio.exceptions.TimeoutError:
                                        embed = discord.Embed(
                                            title = "프로세스 종료",
                                            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await lockunlock.edit(embed=embed)


                            except asyncio.exceptions.TimeoutError:
                                embed = discord.Embed(
                                    title = "프로세스 종료",
                                    description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await prompt.edit(embed=embed)

                        else:
                            embed = discord.Embed(
                                title = "선택 | 디스코드 설정",
                                description = f"⚙️ - 설정 확인\n🗒️ - 로그채널 설정\n🔑 - 권한 설정",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await prompt.edit(embed=embed)

                            for i in discordrole:
                                await prompt.add_reaction(i)

                            def firstcheck(reaction, user):
                                return reaction.message.id == prompt.id and str(reaction.emoji) in discordrole and user == ctx.author

                            try:
                                reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 15)

                                await prompt.clear_reactions()

                                if reaction.emoji == "⚙️":
                                    settingpath = custompath + f"/setting/{serverid}.json"

                                    with open(settingpath) as f:
                                        jsondata = json.load(f)
                                        f.close()

                                    logchannelid = jsondata["logchannelid"]
                                    mod = jsondata["mod"]
                                    admin = jsondata["admin"]
                                    owner = jsondata["owner"]

                                    embed = discord.Embed(
                                        title = "확인 | 디스코드 서버설정",
                                        description = f"로그채널: <#{logchannelid}>\n모드: <@&{mod}>\n어드민: <@&{admin}>\n오너: <@&{owner}>",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)


                                elif reaction.emoji == "🗒️":
                                    embed = discord.Embed(
                                        title = "선택 | 명령어 로그 채널",
                                        description = f"명령어 기록을 로그할 채널을 멘션해주세요.",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    logchnl = await ctx.send(embed=embed)

                                    def chatcheck(author):
                                        def inner_check(message):
                                            return message.author.id == author
                                        return inner_check

                                    try:
                                        msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 30.0)

                                        channelid = msg.content
                                        channelid = channelid[2:-1]
                                        try:
                                            logchannel = discord.utils.get(self.client.get_all_channels(), id =  int(channelid)) 
                                            logchannel.id
                                            serverid = ctx.guild.id
                                            with open(custompath + f"/setting/{serverid}.json") as f:
                                                jsondata = json.load(f)
                                                f.close()
                                            
                                            jsondata["logchannelid"] = logchannel.id

                                            with open(custompath + f"/setting/{serverid}.json", "w") as f:
                                                json.dump(jsondata, f, indent=2)
                                                f.close()     

                                            embed = discord.Embed(
                                                title = "성공 | 로그채널 설정",
                                                description = f"{logchannel.mention}으로 로그채널을 설정했습니다",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await logchnl.edit(embed=embed)
                                        except:
                                            embed = discord.Embed(
                                                title = "에러 | 올바르지 않은 채널",
                                                description = "채널을 멘션해주세요.",
                                                color = discord.Color.from_rgb(255, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await logchnl.edit(embed=embed)
                                        

                                    except asyncio.exceptions.TimeoutError:
                                        embed = discord.Embed(
                                            title = "프로세스 종료",
                                            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await logchnl.edit(embed=embed) 
                                else:
                                    letterlist = ["1️⃣", "2️⃣", "3️⃣"]

                                    embed = discord.Embed(
                                        title = "선택 | 권한설정",
                                        description = f"1️⃣ - 모드(샤우트)\n2️⃣ - 어드민(샤우트, 계급)\n3️⃣ - 오너(샤우트, 계급, 역할설정)",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    modadminowner = await ctx.send(embed=embed)

                                    for i in letterlist:
                                        await modadminowner.add_reaction(i)
                                    
                                    def firstcheck(reaction, user):
                                        return reaction.message.id == modadminowner.id and str(reaction.emoji) in letterlist and user == ctx.author

                                    try:
                                        reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 15)

                                        await modadminowner.clear_reactions()

                                        settingpath = custompath + f"/setting/{serverid}.json"

                                        if reaction.emoji == "1️⃣":
                                            embed = discord.Embed(
                                                title = "선택 | 모드역할",
                                                description = f"모드로 설정할 역할을 멘션해주세요.",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            mod = await ctx.send(embed=embed)

                                            try:
                                                msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 60.0)

                                                roleid = msg.content[3:-1]

                                                try:
                                                    myrole = discord.utils.get(ctx.guild.roles, id=int(roleid))
                                                    myrole.mention

                                                    with open(settingpath) as f:
                                                        jsondata = json.load(f)
                                                        f.close()
                                                    
                                                    jsondata["mod"] = myrole.id

                                                    with open(settingpath, "w") as f:
                                                        json.dump(jsondata, f, indent=2)
                                                        f.close()

                                                    embed = discord.Embed(
                                                        title = "성공 | 모드 역할",
                                                        description = f"모드 역할을 {myrole.mention}으로 설정하였습니다",
                                                        color = discord.Color.from_rgb(0, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await mod.edit(embed=embed)                                                       

                                                except:
                                                    embed = discord.Embed(
                                                        title = "에러 | 올바르지 않은 역할",
                                                        description = "역할을 멘션해주세요.",
                                                        color = discord.Color.from_rgb(255, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await mod.edit(embed=embed)

                                            except asyncio.exceptions.TimeoutError:
                                                embed = discord.Embed(
                                                    title = "프로세스 종료",
                                                    description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await prompt.edit(embed=embed)
                                        elif reaction.emoji == "2️⃣":
                                            embed = discord.Embed(
                                                title = "선택 | 어드민역할",
                                                description = f"어드민로 설정할 역할을 멘션해주세요.",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            mod = await ctx.send(embed=embed)

                                            try:
                                                msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 60.0)

                                                roleid = msg.content[3:-1]

                                                try:
                                                    myrole = discord.utils.get(ctx.guild.roles, id=int(roleid))
                                                    myrole.mention

                                                    with open(settingpath) as f:
                                                        jsondata = json.load(f)
                                                        f.close()
                                                    
                                                    jsondata["admin"] = myrole.id

                                                    with open(settingpath, "w") as f:
                                                        json.dump(jsondata, f, indent=2)
                                                        f.close()

                                                    embed = discord.Embed(
                                                        title = "성공 | 어드민 역할",
                                                        description = f"어드민 역할을 {myrole.mention}으로 설정하였습니다",
                                                        color = discord.Color.from_rgb(0, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await mod.edit(embed=embed)                                                       

                                                except:
                                                    embed = discord.Embed(
                                                        title = "에러 | 올바르지 않은 역할",
                                                        description = "역할을 멘션해주세요.",
                                                        color = discord.Color.from_rgb(255, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await mod.edit(embed=embed)

                                            except asyncio.exceptions.TimeoutError:
                                                embed = discord.Embed(
                                                    title = "프로세스 종료",
                                                    description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await prompt.edit(embed=embed)            
                                        else:
                                            embed = discord.Embed(
                                                title = "선택 | 오너역할",
                                                description = f"오너로 설정할 역할을 멘션해주세요.",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            mod = await ctx.send(embed=embed)

                                            try:
                                                msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 60.0)

                                                roleid = msg.content[3:-1]

                                                try:
                                                    myrole = discord.utils.get(ctx.guild.roles, id=int(roleid))
                                                    myrole.mention

                                                    with open(settingpath) as f:
                                                        jsondata = json.load(f)
                                                        f.close()
                                                    
                                                    jsondata["owner"] = myrole.id

                                                    with open(settingpath, "w") as f:
                                                        json.dump(jsondata, f, indent=2)
                                                        f.close()

                                                    embed = discord.Embed(
                                                        title = "성공 | 오너 역할",
                                                        description = f"오너 역할을 {myrole.mention}으로 설정하였습니다",
                                                        color = discord.Color.from_rgb(0, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await mod.edit(embed=embed)                                                       

                                                except:
                                                    embed = discord.Embed(
                                                        title = "에러 | 올바르지 않은 역할",
                                                        description = "역할을 멘션해주세요.",
                                                        color = discord.Color.from_rgb(255, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await mod.edit(embed=embed)

                                            except asyncio.exceptions.TimeoutError:
                                                embed = discord.Embed(
                                                    title = "프로세스 종료",
                                                    description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await prompt.edit(embed=embed)
                        
                                    except asyncio.exceptions.TimeoutError:
                                        embed = discord.Embed(
                                            title = "프로세스 종료",
                                            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await prompt.edit(embed=embed)

                            except asyncio.exceptions.TimeoutError:
                                embed = discord.Embed(
                                    title = "프로세스 종료",
                                    description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await prompt.edit(embed=embed)

                    except asyncio.exceptions.TimeoutError:
                        embed = discord.Embed(
                            title = "프로세스 종료",
                            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await prompt.edit(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "에러 | 프리미엄 명령어",
                        description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)     
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 연동되지 않음",
                description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["샤우트"])
    async def shout(self, ctx, *, message=None):
        serverowner = ctx.guild.owner_id
        serverid = ctx.guild.id
        what = custompath + f"/setting/{serverid}.json"

        if checkpremium(serverid):
            with open(what) as f:
                jsondata = json.load(f)
                f.close()
            
            modrole = jsondata["mod"]
            adminrole = jsondata["admin"]
            ownerrole = jsondata["owner"]

            permission = 0

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(modrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 1
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(adminrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 2
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(ownerrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 3
            except:
                pass
            #########

            if permission >= 1:
                if message != None:
                    groupid = jsondata["groupid"]
                    logchannelid = jsondata["logchannelid"]

                    r = req.post("https://auth.roblox.com/v2/logout")
                    xcrsftoken = r.headers['X-CSRF-TOKEN']

                    shoutdata = {
                        "message" : message
                    }
                    
                    r = req.patch(f"https://groups.roblox.com/v1/groups/{groupid}/status", json=shoutdata, headers={"X-CSRF-TOKEN": xcrsftoken}).json()

                    try:
                        response = r["body"]

                        if response != message:
                            embed = discord.Embed(
                                title = "에러 | 태그감지",
                                description = f"샤우트에서 의도하지 않은 태그를 발견했습니다.\n{response}",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)
                        else:
                            embed = discord.Embed(
                                title = "성공 | 샤우트 등록",
                                description = f"샤우트를 성공적으로 등록했습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)

                            try:
                                logchannel = discord.utils.get(self.client.get_all_channels(), id = logchannelid)

                                embed = discord.Embed(
                                    title = "로그 | 샤우트 등록",
                                    description = f"명령어 실행자: {ctx.author.mention}\n메세지: {message}\n결과: {response}",
                                    color = discord.Color.from_rgb(0, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await logchannel.send(embed=embed)
                            except:
                                pass

                    except:
                        error = r["errors"][0]["userFacingMessage"]

                        embed = discord.Embed(
                            title = "실패 | 에러확인",
                            description = f"{error}",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)

                else:
                    embed = discord.Embed(
                        title = "에러 | 메세지 필요",
                        description = f"샤우트에 입력할 메세지를 넣어주세요.\n```!샤우트 메세지```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
                  
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"{ctx.author.mention}, 권한이 부족합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 프리미엄 명령어",
                description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["진급", "승진"])
    async def promote(self, ctx, target = None):
        serverowner = ctx.guild.owner_id
        serverid = ctx.guild.id
        what = custompath + f"/setting/{serverid}.json"
        adminver = verifypath + f"/{ctx.author.id}.json"

        if checkpremium(serverid):
            with open(what) as f:
                jsondata = json.load(f)
                f.close()
            
            modrole = jsondata["mod"]
            adminrole = jsondata["admin"]
            ownerrole = jsondata["owner"]
            groupid = jsondata["groupid"]
            logchannelid = jsondata["logchannelid"]
            lockid = list(jsondata["lockid"])
            stophere = jsondata["stophere"]

            permission = 0

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(modrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 1
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(adminrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 2
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(ownerrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 3
            except:
                pass
            #########

            if permission >= 2:
                if target != None:
                    if os.path.isfile(adminver):
                        with open(adminver) as f:
                            jsondata = json.load(f)
                            f.close()
                        adminrobloxid = jsondata["robloxid"]

                        try:
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={target}").json()
                            targetrobloxid = r["Id"]
                        except:
                            targetrobloxid = None
                        if targetrobloxid != None:
                            if targetrobloxid != adminrobloxid:
                                r_target = req.get(f"https://groups.roblox.com/v2/users/{targetrobloxid}/groups/roles").json()

                                mainhit = False
                                for i in r_target["data"]:
                                    if i["group"]["id"] == groupid:
                                        mainhit = True
                                        targetrankset = i["role"]["rank"]
                                        break
                                    else:
                                        pass
                                
                                if mainhit == True:
                                    r_admin = req.get(f"https://groups.roblox.com/v2/users/{adminrobloxid}/groups/roles").json()

                                    for i in r_admin["data"]:
                                        if i["group"]["id"] == groupid:
                                            mainhit = True
                                            adminrankset = i["role"]["rank"]
                                            break
                                        else:
                                            adminrankset = 0
                                    
                                    if targetrankset < adminrankset:
                                        r_group = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()

                                        onemore = True
                                        for i in r_group["roles"]:
                                            if onemore == True:
                                                if i["rank"] == targetrankset:
                                                    formerrankname = i["name"]
                                                    onemore = False
                                                else:
                                                    pass
                                            else:
                                                targetnewrank = i["rank"]
                                                targetnewrankname = i["name"]
                                                targetnewrankid = i["id"]
                                                if targetnewrank in lockid:
                                                    pass
                                                else:
                                                    break
                                        
                                        if targetnewrank < adminrankset:
                                            if targetnewrank < stophere:
                                                r = req.post("https://auth.roblox.com/v2/logout")
                                                xcrsftoken = r.headers['X-CSRF-TOKEN']

                                                jsonrank = {
                                                    "roleId" : targetnewrankid
                                                }

                                                r = req.patch(f"https://groups.roblox.com/v1/groups/{groupid}/users/{targetrobloxid}", json=jsonrank, headers={"X-CSRF-TOKEN": xcrsftoken}).json()

                                                try:
                                                    error = r["errors"]["userFacingMessage"]
                                                    embed = discord.Embed(
                                                        title = "실패 | 에러확인",
                                                        description = f"{error}",
                                                        color = discord.Color.from_rgb(255, 0, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await ctx.send(embed=embed)
                                                except:
                                                    embed = discord.Embed(
                                                        title = "성공 | 역할변경 완료",
                                                        description = f"{targetnewrankname}으로 역할이 올라갔습니다.",
                                                        color = discord.Color.from_rgb(0, 255, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await ctx.send(embed=embed)

                                                    try:
                                                        logchannel = discord.utils.get(self.client.get_all_channels(), id = logchannelid)
                                    
                                                        embed = discord.Embed(
                                                            title = "로그 | 샤우트 등록",
                                                            description = f"명령어 실행자: {ctx.author.mention}\n대상자: {target}\n이전 역할: {formerrankname}\n새로운 역할: {targetnewrankname}",
                                                            color = discord.Color.from_rgb(0, 255, 0)
                                                        )
                                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                                        await logchannel.send(embed=embed)
                                                    except:
                                                        pass



                                            else:
                                                embed = discord.Embed(
                                                    title = "실패 | 최대 변경가능 역할 도달",
                                                    description = f"더 이상의 역할은 명령어로 변경할 수 없습니다.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await ctx.send(embed=embed) 
                                        else:
                                            embed = discord.Embed(
                                                title = "실패 | 더 높은 대상",
                                                description = f"본인과 같은, 또는 더 높은 대상의 역할은 바꿀 수 없습니다.",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await ctx.send(embed=embed)  
                                    else:
                                        embed = discord.Embed(
                                            title = "실패 | 더 높은 대상",
                                            description = f"본인과 같은, 또는 더 높은 대상의 역할은 바꿀 수 없습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)                                           

                                else:
                                    embed = discord.Embed(
                                        title = "실패 | 그룹에 없음",
                                        description = f"대상이 그룹에 가입하지 않았습니다.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)    

                            else:
                                embed = discord.Embed(
                                    title = "실패 | 본인",
                                    description = f"본인 역할을 스스로 바꿀 수 없습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)    
                        else:
                            embed = discord.Embed(
                                title = "에러 | 존재하지 않는 유저",
                                description = f"{target}이라는 이름의 유저를 찾지 못하였습니다.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)                     
                    else:
                        embed = discord.Embed(
                            title = "에러 | 인증 필요",
                            description = f"이 명령어를 사용하려면 인증해주세요.\n```!인증```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)           
                else:
                    embed = discord.Embed(
                        title = "에러 | 유저 필요",
                        description = f"역할을 올린 유저를 넣어주세요.\n```!진급 유저```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"{ctx.author.mention}, 권한이 부족합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 프리미엄 명령어",
                description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")

    @commands.command(aliases=["강등"])
    async def demote(self, ctx, target = None):
        serverowner = ctx.guild.owner_id
        serverid = ctx.guild.id
        what = custompath + f"/setting/{serverid}.json"
        adminver = verifypath + f"/{ctx.author.id}.json"

        if checkpremium(serverid):
            with open(what) as f:
                jsondata = json.load(f)
                f.close()
            
            modrole = jsondata["mod"]
            adminrole = jsondata["admin"]
            ownerrole = jsondata["owner"]
            groupid = jsondata["groupid"]
            logchannelid = jsondata["logchannelid"]
            lockid = list(jsondata["lockid"])
            stophere = jsondata["stophere"]

            permission = 0

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(modrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 1
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(adminrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 2
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(ownerrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 3
            except:
                pass
            #########

            if permission >= 2:
                if target != None:
                    if os.path.isfile(adminver):
                        with open(adminver) as f:
                            jsondata = json.load(f)
                            f.close()
                        adminrobloxid = jsondata["robloxid"]

                        try:
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={target}").json()
                            targetrobloxid = r["Id"]
                        except:
                            targetrobloxid = None
                        if targetrobloxid != None:
                            if targetrobloxid != adminrobloxid:
                                r_target = req.get(f"https://groups.roblox.com/v2/users/{targetrobloxid}/groups/roles").json()

                                mainhit = False
                                for i in r_target["data"]:
                                    if i["group"]["id"] == groupid:
                                        mainhit = True
                                        targetrankset = i["role"]["rank"]
                                        break
                                    else:
                                        pass
                                
                                if mainhit == True:
                                    r_admin = req.get(f"https://groups.roblox.com/v2/users/{adminrobloxid}/groups/roles").json()

                                    for i in r_admin["data"]:
                                        if i["group"]["id"] == groupid:
                                            mainhit = True
                                            adminrankset = i["role"]["rank"]
                                            break
                                        else:
                                            adminrankset = 0
                                    
                                    if targetrankset < adminrankset:
                                        r_group = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()

                                        onemore = True
                                        for i in reversed(r_group["roles"]):
                                            if onemore == True:
                                                if i["rank"] == targetrankset:
                                                    formerrankname = i["name"]
                                                    onemore = False
                                                else:
                                                    pass
                                            else:
                                                targetnewrank = i["rank"]
                                                targetnewrankname = i["name"]
                                                targetnewrankid = i["id"]
                                                if targetnewrank in lockid:
                                                    pass
                                                else:
                                                    break
                                        
                  

                                        r = req.post("https://auth.roblox.com/v2/logout")
                                        xcrsftoken = r.headers['X-CSRF-TOKEN']

                                        jsonrank = {
                                            "roleId" : targetnewrankid
                                        }

                                        r = req.patch(f"https://groups.roblox.com/v1/groups/{groupid}/users/{targetrobloxid}", json=jsonrank, headers={"X-CSRF-TOKEN": xcrsftoken}).json()

                                        try:
                                            error = r["errors"]["userFacingMessage"]
                                            embed = discord.Embed(
                                                title = "실패 | 에러확인",
                                                description = f"{error}",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await ctx.send(embed=embed)
                                        except:
                                            embed = discord.Embed(
                                                title = "성공 | 역할변경 완료",
                                                description = f"{targetnewrankname}으로 역할이 내려갔습니다.",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await ctx.send(embed=embed)
                                            
                                            try:
                                                logchannel = discord.utils.get(self.client.get_all_channels(), id = logchannelid)
                            
                                                embed = discord.Embed(
                                                    title = "로그 | 역할 변경",
                                                    description = f"명령어 실행자: {ctx.author.mention}\n대상자: {target}\n이전 역할: {formerrankname}\n새로운 역할: {targetnewrankname}",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await logchannel.send(embed=embed)
                                            except:
                                                pass


                                    else:
                                        embed = discord.Embed(
                                            title = "실패 | 더 높은 대상",
                                            description = f"본인과 같은, 또는 더 높은 대상의 역할은 바꿀 수 없습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)                                           

                                else:
                                    embed = discord.Embed(
                                        title = "실패 | 그룹에 없음",
                                        description = f"대상이 그룹에 가입하지 않았습니다.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)    

                            else:
                                embed = discord.Embed(
                                    title = "실패 | 본인",
                                    description = f"본인 역할을 스스로 바꿀 수 없습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)    
                        else:
                            embed = discord.Embed(
                                title = "에러 | 존재하지 않는 유저",
                                description = f"{target}이라는 이름의 유저를 찾지 못하였습니다.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)                     
                    else:
                        embed = discord.Embed(
                            title = "에러 | 인증 필요",
                            description = f"이 명령어를 사용하려면 인증해주세요.\n```!인증```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)           
                else:
                    embed = discord.Embed(
                        title = "에러 | 유저 필요",
                        description = f"역할을 올린 유저를 넣어주세요.\n```!강등 유저```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"{ctx.author.mention}, 권한이 부족합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 프리미엄 명령어",
                description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")

    @commands.command(aliases=["역할변경"])
    async def changerank(self, ctx, target = None, towhat = None):
        serverowner = ctx.guild.owner_id
        serverid = ctx.guild.id
        what = custompath + f"/setting/{serverid}.json"
        adminver = verifypath + f"/{ctx.author.id}.json"

        if checkpremium(serverid):
            with open(what) as f:
                jsondata = json.load(f)
                f.close()
            
            modrole = jsondata["mod"]
            adminrole = jsondata["admin"]
            ownerrole = jsondata["owner"]
            groupid = jsondata["groupid"]
            logchannelid = jsondata["logchannelid"]
            lockid = list(jsondata["lockid"])
            stophere = jsondata["stophere"]

            permission = 0

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(modrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 1
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(adminrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 2
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(ownerrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 3
            except:
                pass
            #########

            if permission >= 2:
                if target != None and towhat != None:
                    if os.path.isfile(adminver):
                        with open(adminver) as f:
                            jsondata = json.load(f)
                            f.close()
                        adminrobloxid = jsondata["robloxid"]

                        try:
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={target}").json()
                            targetrobloxid = r["Id"]
                        except:
                            targetrobloxid = None
                        if targetrobloxid != None:
                            if targetrobloxid != adminrobloxid:
                                r_target = req.get(f"https://groups.roblox.com/v2/users/{targetrobloxid}/groups/roles").json()

                                mainhit = False
                                for i in r_target["data"]:
                                    if i["group"]["id"] == groupid:
                                        mainhit = True
                                        targetrankset = i["role"]["rank"]
                                        break
                                    else:
                                        pass
                                
                                if mainhit == True:
                                    r_admin = req.get(f"https://groups.roblox.com/v2/users/{adminrobloxid}/groups/roles").json()

                                    for i in r_admin["data"]:
                                        if i["group"]["id"] == groupid:
                                            mainhit = True
                                            adminrankset = i["role"]["rank"]
                                            break
                                        else:
                                            adminrankset = 0
                                    
                                    if targetrankset < adminrankset:
                                        r_group = req.get(f"https://groups.roblox.com/v1/groups/{groupid}/roles").json()

                                        towhat = int(towhat)
                                        rolehit = False
                                        for i in r_group["roles"]:
                                            if i["rank"] == towhat:
                                                rolehit = True
                                                newrankname = i["name"]
                                                newrankid = i["id"]
                                            else:
                                                pass
                                        
                                        if rolehit == True:

                                            if towhat not in lockid:

                                                if towhat != stophere:
                                                    r = req.post("https://auth.roblox.com/v2/logout")
                                                    xcrsftoken = r.headers['X-CSRF-TOKEN']

                                                    jsonrank = {
                                                        "roleId" : newrankid
                                                    }

                                                    r = req.patch(f"https://groups.roblox.com/v1/groups/{groupid}/users/{targetrobloxid}", json=jsonrank, headers={"X-CSRF-TOKEN": xcrsftoken}).json()

                                                    try:
                                                        error = r["errors"]["userFacingMessage"]
                                                        embed = discord.Embed(
                                                            title = "실패 | 에러확인",
                                                            description = f"{error}",
                                                            color = discord.Color.from_rgb(255, 0, 0)
                                                        )
                                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                                        await ctx.send(embed=embed)
                                                    except:
                                                        embed = discord.Embed(
                                                            title = "성공 | 역할변경 완료",
                                                            description = f"{newrankname}으로 역할을 변경했습니다.",
                                                            color = discord.Color.from_rgb(0, 255, 0)
                                                        )
                                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                                        await ctx.send(embed=embed)
                                                        
                                                        try:
                                                            logchannel = discord.utils.get(self.client.get_all_channels(), id = logchannelid)
                                        
                                                            embed = discord.Embed(
                                                                title = "로그 | 역할 변경",
                                                                description = f"명령어 실행자: {ctx.author.mention}\n대상자: {target}\n새로운 역할: {newrankname}",
                                                                color = discord.Color.from_rgb(0, 255, 0)
                                                            )
                                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                                            await logchannel.send(embed=embed)
                                                        except:
                                                            pass
                                                else:
                                                    embed = discord.Embed(
                                                        title = "실패 | 최대 변경가능 역할 도달",
                                                        description = f"더 이상의 역할은 명령어로 변경할 수 없습니다.",
                                                        color = discord.Color.from_rgb(255, 0, 0)
                                                    )
                                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                                    await ctx.send(embed=embed)                      
                                            else:
                                                embed = discord.Embed(
                                                    title = "실패 | 잠금된 역할",
                                                    description = f"해당 역할 순위는 잠금 상태입니다.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await ctx.send(embed=embed)                  
                                        else:
                                            embed = discord.Embed(
                                                title = "실패 | 역할순위 존재안함",
                                                description = f"역할순위 {towhat}이 존재하지 않습니다",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await ctx.send(embed=embed)                                           


                                    else:
                                        embed = discord.Embed(
                                            title = "실패 | 더 높은 대상",
                                            description = f"본인과 같은, 또는 더 높은 대상의 역할은 바꿀 수 없습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)                                           

                                else:
                                    embed = discord.Embed(
                                        title = "실패 | 그룹에 없음",
                                        description = f"대상이 그룹에 가입하지 않았습니다.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)    

                            else:
                                embed = discord.Embed(
                                    title = "실패 | 본인",
                                    description = f"본인 역할을 스스로 바꿀 수 없습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)    
                        else:
                            embed = discord.Embed(
                                title = "에러 | 존재하지 않는 유저",
                                description = f"{target}이라는 이름의 유저를 찾지 못하였습니다.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)                     
                    else:
                        embed = discord.Embed(
                            title = "에러 | 인증 필요",
                            description = f"이 명령어를 사용하려면 인증해주세요.\n```!인증```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)           
                else:
                    embed = discord.Embed(
                        title = "에러 | 유저 필요",
                        description = f"역할을 올린 유저를 넣어주세요.\n```!역할변경 유저 역할아이디```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"{ctx.author.mention}, 권한이 부족합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 프리미엄 명령어",
                description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")

    @commands.command(aliases=["그룹수락"])
    async def groupaccept(self, ctx, target=None):
        serverowner = ctx.guild.owner_id
        serverid = ctx.guild.id
        what = custompath + f"/setting/{serverid}.json"
        adminver = verifypath + f"/{ctx.author.id}.json"

        if checkpremium(serverid):
            with open(what) as f:
                jsondata = json.load(f)
                f.close()
            
            modrole = jsondata["mod"]
            adminrole = jsondata["admin"]
            ownerrole = jsondata["owner"]
            groupid = jsondata["groupid"]
            logchannelid = jsondata["logchannelid"]

            permission = 0

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(modrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 1
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(adminrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 2
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(ownerrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 3
            except:
                pass
            #########

            if permission >= 3:
                if target != None:
                    if os.path.isfile(adminver):

                        with open(adminver) as f:
                            jsondata = json.load(f)
                            f.close()
                        adminrobloxid = jsondata["robloxid"]
                        try:
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={target}").json()
                            targetrobloxid = r["Id"]
                        except:
                            targetrobloxid = None
                        if targetrobloxid != None:
                            if targetrobloxid != adminrobloxid:
                                r_target = req.get(f"https://groups.roblox.com/v2/users/{targetrobloxid}/groups/roles").json()

                                mainhit = False
                                for i in r_target["data"]:
                                    if i["group"]["id"] == groupid:
                                        mainhit = True
                                        break
                                    else:
                                        pass
                                
                                if mainhit == True:
                                    embed = discord.Embed(
                                        title = "에러 | 그룹에 있는 유저",
                                        description = f"해당 유저는 그룹에 이미 존재합니다.",
                                        color = discord.Color.from_rgb(255, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)                                         

                                else:
                                    r = req.post("https://auth.roblox.com/v2/logout")
                                    xcrsftoken = r.headers['X-CSRF-TOKEN']

                                    r = req.post(f"https://groups.roblox.com/v1/groups/{groupid}/join-requests/users/{targetrobloxid}", headers={"X-CSRF-TOKEN": xcrsftoken}).json()

                                    try:
                                        error = r["errors"][0]["userFacingMessage"]

                                        embed = discord.Embed(
                                            title = "실패 | 에러확인",
                                            description = f"{error}",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                    except:
                                        embed = discord.Embed(
                                            title = "성공 | 그룹수락 완료",
                                            description = f"{target}의 그룹요청을 받았습니다.",
                                            color = discord.Color.from_rgb(0, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                        
                                        try:
                                            logchannel = discord.utils.get(self.client.get_all_channels(), id = logchannelid)
                        
                                            embed = discord.Embed(
                                                title = "로그 | 그룹 수락",
                                                description = f"명령어 실행자: {ctx.author.mention}\n대상자: {target}",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await logchannel.send(embed=embed)
                                        except:
                                            pass
                            else:
                                embed = discord.Embed(
                                    title = "실패 | 본인",
                                    description = f"본인 역할을 스스로 바꿀 수 없습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)    
                        else:
                            embed = discord.Embed(
                                title = "에러 | 존재하지 않는 유저",
                                description = f"{target}이라는 이름의 유저를 찾지 못하였습니다.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)                     
                    else:
                        embed = discord.Embed(
                            title = "에러 | 인증 필요",
                            description = f"이 명령어를 사용하려면 인증해주세요.\n```!인증```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)           
                else:
                    embed = discord.Embed(
                        title = "에러 | 유저 필요",
                        description = f"역할을 올린 유저를 넣어주세요.\n```!그룹수락 유저```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"{ctx.author.mention}, 권한이 부족합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 프리미엄 명령어",
                description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")

    @commands.command(aliases=["그룹추방"])
    async def groupkick(self, ctx, target=None):
        serverowner = ctx.guild.owner_id
        serverid = ctx.guild.id
        what = custompath + f"/setting/{serverid}.json"
        adminver = verifypath + f"/{ctx.author.id}.json"

        if checkpremium(serverid):
            with open(what) as f:
                jsondata = json.load(f)
                f.close()
            
            modrole = jsondata["mod"]
            adminrole = jsondata["admin"]
            ownerrole = jsondata["owner"]
            groupid = jsondata["groupid"]
            logchannelid = jsondata["logchannelid"]

            permission = 0

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(modrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 1
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(adminrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 2
            except:
                pass

            try:
                myrole = discord.utils.get(ctx.guild.roles, id=int(ownerrole))
                myrole.id
                if myrole in ctx.author.roles:
                    permission = 3
            except:
                pass
            #########

            if permission >= 3:
                if target != None:
                    if os.path.isfile(adminver):

                        with open(adminver) as f:
                            jsondata = json.load(f)
                            f.close()
                        adminrobloxid = jsondata["robloxid"]
                        try:
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={target}").json()
                            targetrobloxid = r["Id"]
                        except:
                            targetrobloxid = None
                        if targetrobloxid != None:
                            if targetrobloxid != adminrobloxid:
                                r_target = req.get(f"https://groups.roblox.com/v2/users/{targetrobloxid}/groups/roles").json()

                                mainhit = False
                                for i in r_target["data"]:
                                    if i["group"]["id"] == groupid:
                                        mainhit = True
                                        break
                                    else:
                                        pass
                                
                                if mainhit == False:
                                    embed = discord.Embed(
                                        title = "에러 | 그룹에 없는 유저",
                                        description = f"해당 유저는 그룹에 없습니다.",
                                        color = discord.Color.from_rgb(255, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)                                         

                                else:
                                    r = req.post("https://auth.roblox.com/v2/logout")
                                    xcrsftoken = r.headers['X-CSRF-TOKEN']

                                    print(groupid, targetrobloxid)

                                    r = req.delete(f"https://groups.roblox.com/v1/groups/{groupid}/users/{targetrobloxid}", headers={"X-CSRF-TOKEN": xcrsftoken}).json()
                                    print(r)

                                    try:
                                        error = r["errors"][0]["userFacingMessage"]
                                        embed = discord.Embed(
                                            title = "실패 | 에러확인",
                                            description = f"{error}",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                    except:
                                        embed = discord.Embed(
                                            title = "성공 | 그룹추방 완료",
                                            description = f"{target}을 추방했습니다.",
                                            color = discord.Color.from_rgb(0, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                        
                                        try:
                                            logchannel = discord.utils.get(self.client.get_all_channels(), id = logchannelid)
                        
                                            embed = discord.Embed(
                                                title = "로그 | 그룹 추방",
                                                description = f"명령어 실행자: {ctx.author.mention}\n대상자: {target}",
                                                color = discord.Color.from_rgb(0, 255, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await logchannel.send(embed=embed)
                                        except:
                                            pass
                            else:
                                embed = discord.Embed(
                                    title = "실패 | 본인",
                                    description = f"본인 역할을 스스로 바꿀 수 없습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)    
                        else:
                            embed = discord.Embed(
                                title = "에러 | 존재하지 않는 유저",
                                description = f"{target}이라는 이름의 유저를 찾지 못하였습니다.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)                     
                    else:
                        embed = discord.Embed(
                            title = "에러 | 인증 필요",
                            description = f"이 명령어를 사용하려면 인증해주세요.\n```!인증```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)           
                else:
                    embed = discord.Embed(
                        title = "에러 | 유저 필요",
                        description = f"역할을 올린 유저를 넣어주세요.\n```!그룹추방 유저```",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"{ctx.author.mention}, 권한이 부족합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 프리미엄 명령어",
                description = f"해당 명령어는 프리미엄 고객분들만 사용할 수 있습니다. 프리미엄을 구매해주세요.",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")

    @commands.command(aliases=["프리미엄블랙"])
    async def pblacklist(self, ctx, serverid):
        blacklist = discord.utils.get(self.client.get_all_channels(), id = 829265927882670120)
        if ctx.author.id == ownerid:
            path1 = custompath+f"/setting/{serverid}.json"
            path2 = custompath+f"/time/{serverid}.txt"
            os.remove(path1)
            os.remove(path2)
            await ctx.send("Done")
            await blacklist.send("blacklisted")
    
    @commands.command(aliases=["프리미엄정보"])
    async def pinfo(self, ctx, serverid):
        if ctx.author.id == ownerid:
            path1 = custompath+f"/setting/{serverid}.json"
            if os.path.isfile(path1):
                await ctx.send("True")
            else:
                await ctx.send("False")

def setup(client):
    client.add_cog(premium(client)) 