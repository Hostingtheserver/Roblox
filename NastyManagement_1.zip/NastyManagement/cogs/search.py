import discord
import os
import json
from discord.ext import commands
import datetime
from datetime import date
import aiohttp
import asyncio


session = aiohttp.ClientSession()

async def getrobloxid(robloxname):
    session = aiohttp.ClientSession()
    async with session.get(f"https://api.roblox.com/users/get-by-username?username={robloxname}") as req:
        jsondata = await req.json()

        return jsondata

async def getprofile(userid):
    session = aiohttp.ClientSession()
    async with session.get(f"https://users.roblox.com/v1/users/{userid}") as req:
        jsondata = await req.json()

        return jsondata

async def getgroup(userid):
    session = aiohttp.ClientSession()
    async with session.get(f"https://groups.roblox.com/v1/users/{userid}/groups/roles") as req:
        jsondata = await req.json()

        return jsondata

class search(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command(aliases=["유저검색"])
    async def usersearch(self, ctx, *, robloxname=None):
        #session = aiohttp.ClientSession()
        serverid = ctx.guild.id
        discordname = ctx.author.name 
        discrim = ctx.author.discriminator
        if robloxname == None:
            embed = discord.Embed(
                title = "에러 | 유저이름 미제공",
                description = f"검색할 유저의 이름을 포함해주세요.\n```!유저검색 NastyCore```",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text=f"NastyCore, The Next Innovation")
            await ctx.send(embed=embed)
        else:

            async with session.get(f"https://api.roblox.com/users/get-by-username?username={robloxname}") as req:
                r = await req.json()

            try:
                userid = r["Id"]

                desiredpath = f"client/{serverid}/settings/blacklist.json"

                ifblacklist = False

                if os.path.isfile(desiredpath):
                    with open(desiredpath) as f:
                        jsondata = json.load(f)
                        f.close()
                    userid = int(userid)
                    if userid in jsondata["player"]:
                        ifblacklist = True
            
                serverid = ctx.guild.id
                clientpath = f"client/{serverid}"
                if os.path.isfile(clientpath+"/settings/basicsetting.json"):
                    with open(clientpath+"/settings/basicsetting.json") as f:
                        data = json.load(f)
                        groupid = data["groupid"]
                        f.close()
                else:
                    groupid = None

                async with session.get(f"https://users.roblox.com/v1/users/{userid}") as req:
                    r = await req.json()

                username = r["name"]
                description = r["description"]
                unformatdate = r["created"]
                isbanned = r["isBanned"]
                displayname = r["displayName"]

                datelist = unformatdate[:10].split("-")
                year = datelist[0]
                month = datelist[1]
                day = datelist[2]

                iyear = int(year)
                imonth = int(month)
                iday = int(day)

                rn1 = str(datetime.date.today())
                rn = rn1.split("-")

                nowyear = int(rn[0])
                nowmonth = int(rn[1])
                nowday = int(rn[2])

                target = date(iyear, imonth, iday)
                rightnow = date(nowyear, nowmonth, nowday)

                delta = rightnow-target

                if groupid != None:
                    async with session.get(f"https://groups.roblox.com/v1/users/{userid}/groups/roles") as req:
                        r = await req.json()

                    length = len(r["data"])
                    i = 0
                    hit = False

                    while i < length:
                        if r["data"][i]["group"]["id"] == groupid:
                            foundit = i
                            hit = True
                            break
                        else:
                            i += 1
                    
                    if hit == False:
                        rankname = "Guest(그룹 미가입)"
                    else:
                        rankname = r["data"][foundit]["role"]["name"]
                else:
                    rankname = "그룹연동❌"
                
                if ifblacklist == True:
                    blacklist = "❗ 해당 유저는 이 서버에서 블랙리스트 대상입니다 ❗"
                else:
                    blacklist = ""

                nameresult = f"{username}({userid})"
                if isbanned == True:
                    nameresult = nameresult + " <:banned:820619463267188737>"


                embed=discord.Embed(title=nameresult, description=f"{blacklist}", color = discord.Color.from_rgb(0, 255, 0), url=f"https://www.roblox.com/users/{userid}/profile")
                embed.set_thumbnail(url=f"http://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username={username}")
                embed.add_field(name="디스플레이 닉네임", value=f"`{displayname}`", inline=True)
                embed.add_field(name="아이디", value=f"`{userid}`", inline=True)
                embed.add_field(name="그룹역할", value=f"`{rankname}`", inline=True)
                embed.add_field(name="설명란", value=f"```\n{description}\n```", inline=False)
                embed.add_field(name="계정생성일", value=f"{year}년 {month}월 {day}일", inline=True)
                embed.add_field(name="계정일수", value=f"{delta.days}일", inline=True)
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)


            except:
                embed = discord.Embed(
                    title = "에러 | 유저 존재여부",
                    description = f"{robloxname}이란 로블록스 유저를 찾지 못했습니다.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text=f"NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

    @commands.command(aliases=["유저정보"])
    async def userlookup(self, ctx, target:discord.Member):
        #session = aiohttp.ClientSession()
        serverid = ctx.guild.id
        discordname = ctx.author.name
        discrim = ctx.author.discriminator
        try:
            memberid = target.id

            findmember = f"server/verificationdb/db/{memberid}.json"

            if os.path.isfile(findmember):

                with open(findmember) as f:
                    data = json.load(f)
                    userid = data["robloxid"]
                    f.close()
                
                desiredpath = f"client/{serverid}/settings/blacklist.json"

                ifblacklist = False

                if os.path.isfile(desiredpath):
                    with open(desiredpath) as f:
                        jsondata = json.load(f)
                        f.close()
                    userid = int(userid)
                    if userid in jsondata["player"]:
                        ifblacklist = True


                serverid = ctx.guild.id
                clientpath = f"client/{serverid}"
                if os.path.isfile(clientpath+"/settings/basicsetting.json"):
                    with open(clientpath+"/settings/basicsetting.json") as f:
                        data = json.load(f)
                        groupid = data["groupid"]
                        f.close()
                else:
                    groupid = None

                async with session.get(f"https://users.roblox.com/v1/users/{userid}") as req:
                    r = await req.json()

                username = r["name"]
                description = r["description"]
                unformatdate = r["created"]
                isbanned = r["isBanned"]
                displayname = r["displayName"]

                datelist = unformatdate[:10].split("-")
                year = datelist[0]
                month = datelist[1]
                day = datelist[2]

                iyear = int(year)
                imonth = int(month)
                iday = int(day)

                rn1 = str(datetime.date.today())
                rn = rn1.split("-")

                nowyear = int(rn[0])
                nowmonth = int(rn[1])
                nowday = int(rn[2])

                target = date(iyear, imonth, iday)
                rightnow = date(nowyear, nowmonth, nowday)

                delta = rightnow-target


                if groupid != None:
                    async with session.get(f"https://groups.roblox.com/v1/users/{userid}/groups/roles") as req:
                        r = await req.json()

                    length = len(r["data"])
                    i = 0
                    hit = False

                    while i < length:
                        if r["data"][i]["group"]["id"] == groupid:
                            foundit = i
                            hit = True
                            break
                        else:
                            i += 1
                    
                    if hit == False:
                        rankname = "Guest(그룹 미가입)"
                    else:
                        rankname = r["data"][foundit]["role"]["name"]
                else:
                    rankname = "그룹연동❌"
                
                if ifblacklist == True:
                    blacklist = "❗ 해당 유저는 이 서버에서 블랙리스트 대상입니다 ❗"
                else:
                    blacklist = ""
                
                nameresult = f"{username}({userid})"
                if isbanned == True:
                    nameresult = nameresult + " <:banned:820619463267188737>"

                embed=discord.Embed(title=nameresult, description=f"{blacklist}", color = discord.Color.from_rgb(0, 255, 0), url=f"https://www.roblox.com/users/{userid}/profile")
                embed.set_thumbnail(url=f"http://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username={username}")
                embed.add_field(name="디스플레이 닉네임", value=f"`{displayname}`", inline=True)
                embed.add_field(name="아이디", value=f"`{userid}`", inline=True)
                embed.add_field(name="그룹역할", value=f"`{rankname}`", inline=True)
                embed.add_field(name="설명란", value=f"```\n{description}\n```", inline=False)
                embed.add_field(name="계정생성일", value=f"{year}년 {month}월 {day}일", inline=True)
                embed.add_field(name="계정일수", value=f"{delta.days}일", inline=True)
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)


            else:
                embed = discord.Embed(
                    title = "에러 | 인증 필요",
                    description = f"해당 유저는 인증되지 않았습니다.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text=f"NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        except:
            embed = discord.Embed(
                title = "에러 | 유저 미제공",
                description = f"정보를 얻고싶은 유저를 멘션해주세요.\n로블록스 이름으로 검색하고 싶으시다면 '!유저검색 이름'\n```!유저정보 @맴버멘션```",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text=f"NastyCore, The Next Innovation")
            await ctx.send(embed=embed)



    @commands.command(aliases=["그룹검색"])
    async def searchgroup(self, ctx, groupid=None):
        #session = aiohttp.ClientSession()
        serverid = ctx.guild.id
        discordname = ctx.author.name 
        discrim = ctx.author.discriminator

        if groupid == None:
            embed = discord.Embed(
                title = "에러 | 그룹아이디 미제공",
                description = f"검색할 그룹의 아이디를 포함해주세요.\n```!그룹검색 1```",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            embed.set_footer(text=f"NastyCore, The Next Innovation")
            await ctx.send(embed=embed)
        else:
            async with session.get(f"https://groups.roblox.com/v1/groups/{groupid}") as req:
                r = await req.json()

            try:
                groupname = r["name"]
                description = r["description"]
                ownername = r["owner"]["username"]
                ownerid = r["owner"]["userId"]

                try:
                    shout = r["shout"]["body"]
                except:
                    shout = "없음"
                finally:
                    membercount = r["memberCount"]


                    desiredpath = f"client/{serverid}/settings/blacklist.json"

                    ifblacklist = False

                    if os.path.isfile(desiredpath):
                        with open(desiredpath) as f:
                            jsondata = json.load(f)
                            f.close()
                        groupid = int(groupid)
                        if groupid in jsondata["group"]:
                            ifblacklist = True
                        
                    if ifblacklist == True:
                        embed = discord.Embed(
                            title = f"{groupname}({groupid})",
                            url=f"https://www.roblox.com/groups/{groupid}",
                            description = f"❗**해당 그룹은 이 서버에서 블랙리스트 대상입니다**❗\n\n이름:\n{groupname}\n\n아이디:\n{groupid}\n\n주인:\n{ownername}({ownerid})\n\n그룹설명:\n{description}\n\n샤우트:\n{shout}\n\n그룹 인원:\n{membercount}",
                            color = discord.Color.from_rgb(14, 230, 0)
                        )
                        embed.set_footer(text=f"NastyCore, The Next Innovation | {discordname}#{discrim}")
                        await ctx.send(embed=embed)
                    else:

                        embed = discord.Embed(
                            title = f"{groupname}({groupid})",
                            url=f"https://www.roblox.com/groups/{groupid}",
                            description = f"이름:\n{groupname}\n\n아이디:\n{groupid}\n\n주인:\n{ownername}({ownerid})\n\n그룹설명:\n{description}\n\n샤우트:\n{shout}\n\n그룹 인원:\n{membercount}",
                            color = discord.Color.from_rgb(14, 230, 0)
                        )
                        embed.set_footer(text=f"NastyCore, The Next Innovation | {discordname}#{discrim}")
                        await ctx.send(embed=embed)

            except:
                embed = discord.Embed(
                    title = "에러 | 그룹 존재여부",
                    description = f"해당 그룹은 존재하지 않습니다.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text=f"NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

    @commands.command(aliases=["그룹정보"])
    async def grouplookup(self, ctx):
        #session = aiohttp.ClientSession()
        serverid = ctx.guild.id
        discordname = ctx.author.name
        discrim = ctx.author.discriminator

        checkexist =  f"client/{serverid}/exist.json"
        desiredpath = f"client/{serverid}/settings/blacklist.json"
        basicsetting = f"client/{serverid}/settings/basicsetting.json"
        
        if os.path.isfile(checkexist):
            with open(basicsetting) as f:
                jsondata = json.load(f)
                f.close()
            
            groupid = jsondata["groupid"]

            async with session.get(f"https://groups.roblox.com/v1/groups/{groupid}") as req:
                r = await req.json()


            try:
                groupname = r["name"]
                description = r["description"]
                ownername = r["owner"]["username"]
                ownerid = r["owner"]["userId"]

                try:
                    shout = r["shout"]["body"]
                except:
                    shout = "없음"
                finally:
                    membercount = r["memberCount"]
                    
                    membercount = r["memberCount"]


                    desiredpath = f"client/{serverid}/settings/blacklist.json"

                    ifblacklist = False

                    if os.path.isfile(desiredpath):
                        with open(desiredpath) as f:
                            jsondata = json.load(f)
                            f.close()
                        groupid = int(groupid)
                        if groupid in jsondata["group"]:
                            ifblacklist = True
                        
                    if ifblacklist == True:
                        embed = discord.Embed(
                            title = f"{groupname}({groupid})",
                            url=f"https://www.roblox.com/groups/{groupid}",
                            description = f"❗**해당 그룹은 이 서버에서 블랙리스트 대상입니다**❗\n\n이름:\n{groupname}\n\n아이디:\n{groupid}\n\n주인:\n{ownername}({ownerid})\n\n그룹설명:\n{description}\n\n샤우트:\n{shout}\n\n그룹 인원:\n{membercount}",
                            color = discord.Color.from_rgb(14, 230, 0)
                        )
                        embed.set_footer(text=f"NastyCore, The Next Innovation | {discordname}#{discrim}")
                        await ctx.send(embed=embed)
                    else:

                        embed = discord.Embed(
                            title = f"{groupname}({groupid})",
                            url=f"https://www.roblox.com/groups/{groupid}",
                            description = f"이름:\n{groupname}\n\n아이디:\n{groupid}\n\n주인:\n{ownername}({ownerid})\n\n그룹설명:\n{description}\n\n샤우트:\n{shout}\n\n그룹 인원:\n{membercount}",
                            color = discord.Color.from_rgb(14, 230, 0)
                        )
                        embed.set_footer(text=f"NastyCore, The Next Innovation | {discordname}#{discrim}")
                        await ctx.send(embed=embed)

            except:
                embed = discord.Embed(
                    title = "에러 | 그룹 존재여부",
                    description = f"해당 그룹은 존재하지 않습니다.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text=f"NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 연동되지 않음",
                description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

def setup(client):
    client.add_cog(search(client))