import discord
import os
import json
from discord.ext import commands
import requests
import random


botownerid = 631441731350691850

class setting(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command(aliases=["설정확인", "설정"])
    async def setting(self, ctx, whattype = None):
        serverid = ctx.guild.id 
        ############################
        clientpath = f"client/{serverid}"
        exist = clientpath+"/exist.json"
        nameformat = clientpath+"/settings/nameformat.json"
        nameset = clientpath+"/settings/nameset.json"
        basicsetting = clientpath+"/settings/basicsetting.json"
        bindsetting = clientpath+"/settings/bindsetting.json"
        logsetting = clientpath+"/settings/logsetting.json"

        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            if os.path.isfile(exist):
                if whattype == None:
                    embed = discord.Embed(
                        title = "에러 | 선택지 미제공",
                        description = f"역할, 이름, 로그중 골라주세요.\n```!설정 역할```",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
                elif whattype == "역할":

                    with open(basicsetting) as f:
                        basicdata = json.load(f)
                        f.close()

                    groupid = basicdata["groupid"]

                    f = open(bindsetting)
                    message = f.read()
                    f.close()

                    embed = discord.Embed(
                        title = "설정 | 역할아이디 확인",
                        description = f"그룹 아이디: {groupid}\n```{message}```\n안에 있는 숫자는 역할 아이디를 의미합니다.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)                     
                    
                elif whattype == "이름":

                    with open(basicsetting) as f:
                        basicdata = json.load(f)
                        f.close()

                    groupid = basicdata["groupid"]

                    f = open(nameformat)
                    message = f.read()
                    f.close()

                    embed = discord.Embed(
                        title = "설정 | 이름형식 확인",
                        description = f"그룹 아이디: {groupid}\n```{message}```\n안에 있는 숫자는 역할 아이디를 의미합니다.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed) 

                elif whattype == "로그":
                    with open(logsetting) as f:
                        logdata = json.load(f)
                        f.close()
                    
                    premium = logdata["premiumlog"]
                    blacklist = logdata["blacklistlog"]
                    setup = logdata["serversetuplog"]

                    embed = discord.Embed(
                        title = "설정 | 로그채널 확인",
                        description = f"서버설정 채널: <#{setup}>\n블랙리스트 채널: <#{blacklist}>\n프리미엄 채널: <#{premium}>",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)  

                else:
                    embed = discord.Embed(
                        title = "에러 | 선택지 미제공",
                        description = f"역할, 이름중 골라주세요.\n```!설정 역할```",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed) 


            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)

    @commands.command(aliases=["로그설정"])
    async def logsetting(self, ctx, whattype = None, mychannel:discord.TextChannel=None):
        serverid = ctx.guild.id 
        ############################
        clientpath = f"client/{serverid}"
        exist = clientpath+"/exist.json"
        logsetting = clientpath+"/settings/logsetting.json"
        
        channelid = mychannel.id

        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == botownerid:
            if os.path.isfile(exist):
                if whattype != None and mychannel != None:
                    if whattype == "프리미엄":
                        with open(logsetting) as f:
                            logdata = json.load(f)
                            f.close()

                        logdata["premiumlog"] = channelid

                        with open(logsetting, "w") as f:
                            json.dump(logdata, f, indent=2)
                            f.close()
                        
                        embed = discord.Embed(
                            title = f"성공 | 프리미엄 로그",
                            description = f"앞으로 모든 프리미엄 관련 로그는 {mychannel.mention}에 남습니다.",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)


                    elif whattype == "블랙리스트":

                        with open(logsetting) as f:
                            logdata = json.load(f)
                            f.close()

                        logdata["blacklistlog"] = channelid

                        with open(logsetting, "w") as f:
                            json.dump(logdata, f, indent=2)
                            f.close()
                        
                        embed = discord.Embed(
                            title = f"성공 | 블랙리스트 로그",
                            description = f"앞으로 모든 블랙리스트 관련 로그는 {mychannel.mention}에 남습니다.",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)
                    elif whattype == "서버설정":

                        with open(logsetting) as f:
                            logdata = json.load(f)
                            f.close()

                        logdata["serversetuplog"] = channelid

                        with open(logsetting, "w") as f:
                            json.dump(logdata, f, indent=2)
                            f.close()
                        
                        embed = discord.Embed(
                            title = f"성공 | 서버설정 로그",
                            description = f"앞으로 모든 서버설정 관련 로그는 {mychannel.mention}에 남습니다.",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)
                    else:
                        embed = discord.Embed(
                            title = f"에러 | 선택지 미제공",
                            description = f"로그 채널을 설정합니다\n`!로그설정 <프리미엄/블랙리스트/그룹설정> <#채널멘션>`",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = f"에러 | 선택지 미제공",
                        description = f"로그 채널을 설정합니다.\n`!로그설정 <프리미엄/블랙리스트/그룹설정> <#채널멘션>`",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)    
            else:
                embed = discord.Embed(
                    title = "에러 | 연동되지 않음",
                    description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)




def setup(client):
    client.add_cog(setting(client))