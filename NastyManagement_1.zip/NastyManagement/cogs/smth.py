import discord
import os
import json
from discord.ext import commands
import requests
import random

class smth(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command()
    async def c7rn(self, ctx, userid=None):
        if ctx.author.id == 631441731350691850:
            async for guild in self.client.fetch_guilds(limit=None):
                guildid = guild.id

                realguild = self.client.get_guild(guildid)

                print(findmember = realguild.get_member(userid))
        

def setup(client):
    client.add_cog(smth(client))