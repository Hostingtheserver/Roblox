import discord
import os
import json
from discord.ext import commands
import asyncio
import aiohttp

session = aiohttp.ClientSession()

ownerid = 631441731350691850
custompath = "server/regulardb"

def getcommand(ctx):
    splitlist = ctx.split(" ")[0]
    return splitlist

def checkcustomer(server):
    path = custompath + f"/{server}.txt"
    if os.path.isfile(path):
        return True
    else:
        return False

class update(commands.Cog):

    def __init__(self, client):
        self.client = client
    

    @commands.command(aliases=["업데이트"])
    async def update(self, ctx, target:discord.Member=None):
        if checkcustomer(ctx.guild.id) == True:

            if getcommand(ctx.message.content) == "!업데이트":
                serverid = ctx.guild.id 
                ############################
                clientpath = f"client/{serverid}"
                exist = clientpath+"/exist.json"
                nameformat = clientpath+"/settings/nameformat.json"
                nameset = clientpath+"/settings/nameset.json"
                basicsetting = clientpath+"/settings/basicsetting.json"
                bindsetting = clientpath+"/settings/bindsetting.json"
                desiredpath = f"client/{serverid}/settings/blacklist.json"
                shouldupdate = f"client/{serverid}/supdate.txt"
                

                serverpath = f"server"
                #############################
                #순서: bypass 확인, 이름, 그룹, 계급, 서브그룹
                if os.path.isfile(shouldupdate):
                    bypass = discord.utils.get(ctx.guild.roles, name="nastybypass")
                    
                    if target == None:
                        target = ctx.author
                        #여기서부터 복사
                        verificationdb = serverpath+f"/verificationdb/db/{target.id}.json"

                        if os.path.isfile(exist):
                            if os.path.isfile(verificationdb):
                                with open(verificationdb) as f:
                                    data = json.load(f)
                                    f.close()
                                
                                robloxid = data["robloxid"]

                                async with session.get(f"https://api.roblox.com/users/{robloxid}") as f:
                                    r = await f.json()

                                robloxname = r["Username"]

                                async with session.get(f"https://groups.roblox.com/v1/users/{robloxid}/groups/roles") as f:
                                    groupdata = await f.json()

                                with open(basicsetting) as f:
                                    data = json.load(f)
                                    f.close()
                                main_group_id = data["groupid"]

                                blacklisted = False
                                blgroupname = None
                                if os.path.isfile(desiredpath):
                                    with open(desiredpath) as f:
                                        blacklistdata = json.load(f)
                                        f.close()
                                    
                                    if int(robloxid) in blacklistdata["player"]:
                                        blacklisted = True
                                    else:
                                        i = 0
                                        while i < len(groupdata["data"]):
                                            groupid = groupdata["data"][i]["group"]["id"]

                                            if int(groupid) in blacklistdata["group"]:
                                                blacklisted = True
                                                blgroupname = groupdata["data"][i]["group"]["name"]
                                                break
                                            else:
                                                i += 1
                                else:
                                    pass
                                    
                                if blacklisted == False:

                                    mainhit = False
                                    i = 0
                                    while i < len(groupdata["data"]):
                                        group = groupdata["data"][i]["group"]["id"]
                                        if group == main_group_id:
                                            mainhit = True
                                            rankid = groupdata["data"][i]["role"]["rank"]
                                            break
                                        else:
                                            rankid = 0
                                            i += 1
                                
                                    with open(bindsetting) as f:
                                        binddata = json.load(f)
                                        f.close()
                                    
                                    whitelist = [] 

                                    giverole = []

                                    for x in binddata["whitelisted"]:
                                        whitelist.append(x)

                                    try:
                                        getthisrole = binddata[str(rankid)]
                                        for x in getthisrole:
                                            giverole.append(x)
                                    except:
                                        pass

                                    if mainhit == True:
                                        try:
                                            for x in binddata["maingroup"]:
                                                giverole.append(x)
                                        except:
                                            pass
                                
                                    subgroupid = []

                                    subhit = False
                                    i = 0

                                    while i < len(groupdata["data"]):
                                        group = groupdata["data"][i]["group"]["id"]
                                        subgroupid.append(str(group))
                                        i += 1
                                    
                                    for x in subgroupid:
                                        try:
                                            roleid = binddata["subgroup"][x]
                                            giverole.append(roleid)
                                        except:
                                            pass 
                                    
                                    if os.path.isfile(nameset):
                                        with open(nameset) as f:
                                            namesetdata = json.load(f)
                                            f.close()
                                        givenameformat = namesetdata["nameformat"]

                                        with open(nameformat) as f:
                                            namedata = json.load(f)
                                            f.close()
                                        try:
                                            hisnamedata = namedata[str(rankid)]
                                            hisnamedata = hisnamedata[0]
                                        except:
                                            if mainhit == False:
                                                try:
                                                    hisnamedata = namedata["0"]
                                                    hisnamedata = hisnamedata[0]
                                                except:
                                                    hisnamedata = None
                                            else:
                                                hisnamedata = None

                                        targetname = ""
                                        for x in givenameformat:
                                            if x == "1":
                                                if robloxname == None:
                                                    continue
                                                else:
                                                    targetname += f"{robloxname}"
                                            elif x == "2":
                                                if hisnamedata == None:
                                                    continue
                                                else:
                                                    targetname += f"{hisnamedata}"
                                            elif x == "3":
                                                targetname += f"{target.name}"
                                            else:
                                                targetname += x

                                    else:
                                        targetname = target.display_name

                                    #giverole에 없고 whitelist에 없으면 빼고, giverole 주고 이름 바꿔

                                    addresult = ""
                                    removeresult = ""
                                    nameresult = ""

                                    for x in giverole:
                                        myrole = discord.utils.get(ctx.guild.roles, id=int(x))

                                        if myrole in target.roles:
                                            pass
                                        else:
                                            try:
                                                await target.add_roles(myrole)
                                                addresult += f"\n+{myrole.mention}"
                                            except:
                                                continue
                                    
                                    for x in target.roles:
                                        roleid = x.id 
                                        if roleid in giverole:
                                            continue
                                        else:
                                            if roleid in whitelist:
                                                continue
                                            else:
                                                if x.name != "nastybypass":
                                                    try:
                                                        await target.remove_roles(x)
                                                        if x.mention != "@@everyone":
                                                            removeresult += f"\n-{x.mention}"
                                                    except:
                                                        continue
                                    try:
                                        await target.edit(nick=targetname)
                                        nameresult = targetname

                                    except:
                                        nameresult = "실패(권한확인)"

                                    
                                    if addresult == None or addresult == "":
                                        addresult = "없음"
                                    if removeresult == None or removeresult == "":
                                        removeresult = "없음"


                                    embed = discord.Embed(
                                        title = "성공 | 업데이트",
                                        description = f"이름:\n{nameresult}",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.add_field(name="추가된 역할", value= addresult, inline=True)
                                    embed.add_field(name="제거된 역할", value= removeresult, inline=True)
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await ctx.send(embed=embed)
                                else:
                                    if blgroupname != None:

                                        nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                        for x in target.roles:
                                            try:
                                                await target.remove_roles(x)
                                            except:
                                                pass

                                        embed = discord.Embed(
                                            title = "에러 | 블랙리스트 그룹",
                                            description = f"업데이트할 유저는 블랙리스트된 그룹에 속해있습니다.\n`{blgroupname}`",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                    else:
                                        nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                        for x in target.roles:
                                            try:
                                                await target.remove_roles(x)
                                            except:
                                                pass

                                        embed = discord.Embed(
                                            title = "에러 | 블랙리스트 유저",
                                            description = f"업데이트할 유저는 블랙리스트된 상태입니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)

                            else:
                                embed = discord.Embed(
                                    title = "실패 | 인증필요",
                                    description = f"인증이 안된 상태입니다. 인증을 해주세요.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)
                        else:
                            embed = discord.Embed(
                                title = "에러 | 그룹연동 필요",
                                description = f"그룹연동을 우선적으로 해주세요.\n```!그룹연동 그룹아이디```",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await ctx.send(embed=embed)

                    else:
                        bypass = discord.utils.get(ctx.guild.roles, name="nastybypass")
                        if bypass not in target.roles:
                            verificationdb = serverpath+f"/verificationdb/db/{target.id}.json"

                            if os.path.isfile(exist):
                                if os.path.isfile(verificationdb):
                                    with open(verificationdb) as f:
                                        data = json.load(f)
                                        f.close()
                                    
                                    robloxid = data["robloxid"]
                                    async with session.get(f"https://api.roblox.com/users/{robloxid}") as f:
                                        r = await f.json()

                                    robloxname = r["Username"]

                                    async with session.get(f"https://groups.roblox.com/v1/users/{robloxid}/groups/roles") as f:
                                        groupdata = await f.json()

                                    with open(basicsetting) as f:
                                        data = json.load(f)
                                        f.close()
                                    main_group_id = data["groupid"]


                                    blacklisted = False
                                    blgroupname = None
                                    if os.path.isfile(desiredpath):
                                        with open(desiredpath) as f:
                                            blacklistdata = json.load(f)
                                            f.close()
                                        
                                        if int(robloxid) in blacklistdata["player"]:
                                            blacklisted = True
                                        else:
                                            i = 0
                                            while i < len(groupdata["data"]):
                                                groupid = groupdata["data"][i]["group"]["id"]

                                                if int(groupid) in blacklistdata["group"]:
                                                    blacklisted = True
                                                    blgroupname = groupdata["data"][i]["group"]["name"]
                                                    break
                                                else:
                                                    i += 1
                                    else:
                                        pass

                                    if blacklisted == False:

                                        mainhit = False
                                        i = 0
                                        while i < len(groupdata["data"]):
                                            group = groupdata["data"][i]["group"]["id"]
                                            if group == main_group_id:
                                                mainhit = True
                                                rankid = groupdata["data"][i]["role"]["rank"]
                                                break
                                            else:
                                                rankid = 0
                                                i += 1
                                    
                                        with open(bindsetting) as f:
                                            binddata = json.load(f)
                                            f.close()
                                        
                                        whitelist = [] 

                                        giverole = []

                                        for x in binddata["whitelisted"]:
                                            whitelist.append(x)

                                        try:
                                            getthisrole = binddata[str(rankid)]
                                            for x in getthisrole:
                                                giverole.append(x)
                                        except:
                                            pass

                                        if mainhit == True:
                                            try:
                                                for x in binddata["maingroup"]:
                                                    giverole.append(x)
                                            except:
                                                pass
                                        
                                        subgroupid = []

                                        subhit = False
                                        i = 0

                                        while i < len(groupdata["data"]):
                                            group = groupdata["data"][i]["group"]["id"]
                                            subgroupid.append(str(group))
                                            i += 1
                                        
                                        for x in subgroupid:
                                            try:
                                                roleid = binddata["subgroup"][x]
                                                giverole.append(roleid)
                                            except:
                                                pass 
                                        
                                        if os.path.isfile(nameset):
                                            with open(nameset) as f:
                                                namesetdata = json.load(f)
                                                f.close()
                                            givenameformat = namesetdata["nameformat"]

                                            with open(nameformat) as f:
                                                namedata = json.load(f)
                                                f.close()
                                            try:
                                                hisnamedata = namedata[str(rankid)]
                                                hisnamedata = hisnamedata[0]
                                            except:
                                                if mainhit == False:
                                                    try:
                                                        hisnamedata = namedata["0"]
                                                        hisnamedata = hisnamedata[0]
                                                    except:
                                                        hisnamedata = None
                                                else:
                                                    hisnamedata = None


                                            targetname = ""
                                            for x in givenameformat:
                                                if x == "1":
                                                    if robloxname == None:
                                                        continue
                                                    else:
                                                        targetname += f"{robloxname}"
                                                elif x == "2":
                                                    if hisnamedata == None:
                                                        continue
                                                    else:
                                                        targetname += f"{hisnamedata}"
                                                elif x == "3":
                                                    targetname += f"{target.name}"
                                                else:
                                                    targetname += x

                                        else:
                                            targetname = target.display_name

                                        #giverole에 없고 whitelist에 없으면 빼고, giverole 주고 이름 바꿔

                                        addresult = ""
                                        removeresult = ""
                                        nameresult = ""

                                        for x in giverole:
                                            myrole = discord.utils.get(ctx.guild.roles, id=int(x))

                                            if myrole in target.roles:
                                                pass
                                            else:
                                                try:
                                                    await target.add_roles(myrole)
                                                    addresult += f"\n+{myrole.mention}"
                                                except:
                                                    continue 
                                        
                                        for x in target.roles:
                                            roleid = x.id 
                                            if roleid in giverole:
                                                continue
                                            else:
                                                if roleid in whitelist:
                                                    continue
                                                else:
                                                    if x.name != "nastybypass":
                                                        try:
                                                            await target.remove_roles(x)
                                                            if x.mention != "@@everyone":
                                                                removeresult += f"\n-{x.mention}"
                                                        except:
                                                            continue

                                        try:
                                            await target.edit(nick=targetname)
                                            nameresult = targetname
                                        except:
                                            nameresult = "실패(권한확인)"
                                            
                                        embed = discord.Embed(
                                            title = "성공 | 업데이트",
                                            description = f"이름:\n{nameresult}\n\n추가된 역할:\n{addresult}\n\n제거된 역할:\n{removeresult}\n\n",
                                            color = discord.Color.from_rgb(0, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                    else:
                                        if blgroupname != None:

                                            nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                            for x in target.roles:
                                                try:
                                                    await target.remove_roles(x)
                                                except:
                                                    pass

                                            embed = discord.Embed(
                                                title = "업데이트 실패",
                                                description = f"업데이트할 유저는 블랙리스트된 그룹에 속해있습니다\n`{blgroupname}`",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await ctx.send(embed=embed)
                                        else:
                                            nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                            for x in target.roles:
                                                try:
                                                    await target.remove_roles(x)
                                                except:
                                                    pass

                                            embed = discord.Embed(
                                                title = "업데이트 실패",
                                                description = f"업데이트할 유저는 블랙리스트된 상태입니다",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation")
                                            await ctx.send(embed=embed)



                                else:

                                    nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                    if nastybypass in target.roles:
                                        embed = discord.Embed(
                                            title = "업데이트 실패",
                                            description = f"해당 유저에게 'nastybypass'라는 역할이 있습니다",
                                            color = discord.Color.from_rgb(255, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                    else:
                                        for x in target.roles:
                                            try:
                                                await target.remove_roles(x)
                                            except:
                                                pass

                                        embed = discord.Embed(
                                            title = "업데이트 실패",
                                            description = f"업데이트할 유저는 인증이 안된 상태입니다\n역할이 모두 제거됐습니다",
                                            color = discord.Color.from_rgb(255, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                            else:
                                embed = discord.Embed(
                                    title = "업데이트 실패",
                                    description = f"그룹연동을 우선적으로 해주세요\n```!그룹연동 그룹아이디```",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)
                        else:
                                embed = discord.Embed(
                                    title = "업데이트 실패",
                                    description = f"해당 유저에게는 'nastybypass'역할이 있어 본인만 직접 업데이트를 사용 가능합니다.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "업데이트 불가",
                        description = f"이 서버는 업데이트가 비활성화된 상태입니다. 업데이트를 활성화시키고 싶으면\n```!업데이트활성화```명령어를 사용해주세요",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                serverid = ctx.guild.id 
                ############################
                clientpath = f"client/{serverid}"
                exist = clientpath+"/exist.json"
                nameformat = clientpath+"/settings/nameformat.json"
                nameset = clientpath+"/settings/nameset.json"
                basicsetting = clientpath+"/settings/basicsetting.json"
                bindsetting = clientpath+"/settings/bindsetting.json"
                desiredpath = f"client/{serverid}/settings/blacklist.json"
                shouldupdate = f"client/{serverid}/supdate.txt"
                

                serverpath = f"server"
                #############################
                #순서: bypass 확인, 이름, 그룹, 계급, 서브그룹
                if os.path.isfile(shouldupdate):
                    bypass = discord.utils.get(ctx.guild.roles, name="nastybypass")
                    
                    if target == None:
                        target = ctx.author
                        #여기서부터 복사
                        verificationdb = serverpath+f"/verificationdb/db/{target.id}.json"

                        if os.path.isfile(exist):
                            if os.path.isfile(verificationdb):
                                with open(verificationdb) as f:
                                    data = json.load(f)
                                    f.close()
                                
                                robloxid = data["robloxid"]

                                async with session.get(f"https://api.roblox.com/users/{robloxid}") as f:
                                    r = await f.json()

                                robloxname = r["Username"]

                                async with session.get(f"https://groups.roblox.com/v1/users/{robloxid}/groups/roles") as f:
                                    groupdata = await f.json()

                                with open(basicsetting) as f:
                                    data = json.load(f)
                                    f.close()
                                main_group_id = data["groupid"]

                                blacklisted = False
                                blgroupname = None
                                if os.path.isfile(desiredpath):
                                    with open(desiredpath) as f:
                                        blacklistdata = json.load(f)
                                        f.close()
                                    
                                    if int(robloxid) in blacklistdata["player"]:
                                        blacklisted = True
                                    else:
                                        i = 0
                                        while i < len(groupdata["data"]):
                                            groupid = groupdata["data"][i]["group"]["id"]

                                            if int(groupid) in blacklistdata["group"]:
                                                blacklisted = True
                                                blgroupname = groupdata["data"][i]["group"]["name"]
                                                break
                                            else:
                                                i += 1
                                else:
                                    pass
                                    
                                if blacklisted == False:

                                    mainhit = False
                                    i = 0
                                    while i < len(groupdata["data"]):
                                        group = groupdata["data"][i]["group"]["id"]
                                        if group == main_group_id:
                                            mainhit = True
                                            rankid = groupdata["data"][i]["role"]["rank"]
                                            break
                                        else:
                                            rankid = 0
                                            i += 1
                                
                                    with open(bindsetting) as f:
                                        binddata = json.load(f)
                                        f.close()
                                    
                                    whitelist = [] 

                                    giverole = []

                                    for x in binddata["whitelisted"]:
                                        whitelist.append(x)

                                    try:
                                        getthisrole = binddata[str(rankid)]
                                        for x in getthisrole:
                                            giverole.append(x)
                                    except:
                                        pass

                                    if mainhit == True:
                                        try:
                                            for x in binddata["maingroup"]:
                                                giverole.append(x)
                                        except:
                                            pass
                                
                                    subgroupid = []

                                    subhit = False
                                    i = 0

                                    while i < len(groupdata["data"]):
                                        group = groupdata["data"][i]["group"]["id"]
                                        subgroupid.append(str(group))
                                        i += 1
                                    
                                    for x in subgroupid:
                                        try:
                                            roleid = binddata["subgroup"][x]
                                            giverole.append(roleid)
                                        except:
                                            pass 
                                    
                                    if os.path.isfile(nameset):
                                        with open(nameset) as f:
                                            namesetdata = json.load(f)
                                            f.close()
                                        givenameformat = namesetdata["nameformat"]

                                        with open(nameformat) as f:
                                            namedata = json.load(f)
                                            f.close()
                                        try:
                                            hisnamedata = namedata[str(rankid)]
                                            hisnamedata = hisnamedata[0]
                                        except:
                                            if mainhit == False:
                                                try:
                                                    hisnamedata = namedata["0"]
                                                    hisnamedata = hisnamedata[0]
                                                except:
                                                    hisnamedata = None
                                            else:
                                                hisnamedata = None

                                        targetname = ""
                                        for x in givenameformat:
                                            if x == "1":
                                                if robloxname == None:
                                                    continue
                                                else:
                                                    targetname += f"{robloxname}"
                                            elif x == "2":
                                                if hisnamedata == None:
                                                    continue
                                                else:
                                                    targetname += f"{hisnamedata}"
                                            elif x == "3":
                                                targetname += f"{target.name}"
                                            else:
                                                targetname += x

                                    else:
                                        targetname = target.display_name

                                    #giverole에 없고 whitelist에 없으면 빼고, giverole 주고 이름 바꿔

                                    addresult = ""
                                    removeresult = ""
                                    nameresult = ""

                                    for x in giverole:
                                        myrole = discord.utils.get(ctx.guild.roles, id=int(x))

                                        if myrole in target.roles:
                                            pass
                                        else:
                                            try:
                                                await target.add_roles(myrole)
                                                addresult += f"\n+{myrole.mention}"
                                            except:
                                                continue
                                    
                                    for x in target.roles:
                                        roleid = x.id 
                                        if roleid in giverole:
                                            continue
                                        else:
                                            if roleid in whitelist:
                                                continue
                                            else:
                                                if x.name != "nastybypass":
                                                    try:
                                                        await target.remove_roles(x)
                                                        if x.mention != "@@everyone":
                                                            removeresult += f"\n-{x.mention}"
                                                    except:
                                                        continue
                                    try:
                                        await target.edit(nick=targetname)
                                        nameresult = targetname
                                    except:
                                        nameresult = "Fail(Permission error)"
                                    
                                    embed = discord.Embed(
                                        title = "Success | Updated",
                                        description = f"Name:\n{nameresult}\n\nAdded roles:\n{addresult}\n\nRemoved roles:\n{removeresult}\n\n",
                                        color = discord.Color.from_rgb(0, 255, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                    await ctx.send(embed=embed)
                                else:
                                    if blgroupname != None:

                                        nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                        for x in target.roles:
                                            try:
                                                await target.remove_roles(x)
                                            except:
                                                pass

                                        embed = discord.Embed(
                                            title = "Error | Blacklisted group",
                                            description = f"User trying to be updated is in a blacklisted group.\n`{blgroupname}`",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                        await ctx.send(embed=embed)
                                    else:
                                        nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                        for x in target.roles:
                                            try:
                                                await target.remove_roles(x)
                                            except:
                                                pass

                                        embed = discord.Embed(
                                            title = "Error | Blacklisted user",
                                            description = f"User trying to be updated is blacklisted.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                        await ctx.send(embed=embed)

                            else:
                                embed = discord.Embed(
                                    title = "Error | User not verified",
                                    description = f"It seems that you aren't verified. All of your roles are removed.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                await ctx.send(embed=embed)
                        else:
                            embed = discord.Embed(
                                title = "Error | Server not setted up",
                                description = f"Please tell the owner to set the server up.\nWe currently don't support english version of server setup.",
                                color = discord.Color.from_rgb(255, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                            await ctx.send(embed=embed)

                    else:
                        bypass = discord.utils.get(ctx.guild.roles, name="nastybypass")
                        if bypass not in target.roles:
                            verificationdb = serverpath+f"/verificationdb/db/{target.id}.json"

                            if os.path.isfile(exist):
                                if os.path.isfile(verificationdb):
                                    with open(verificationdb) as f:
                                        data = json.load(f)
                                        f.close()
                                    
                                    robloxid = data["robloxid"]

                                    async with session.get(f"https://api.roblox.com/users/{robloxid}") as f:
                                        r = await f.json()

                                    robloxname = r["Username"]

                                    async with session.get(f"https://groups.roblox.com/v1/users/{robloxid}/groups/roles") as f:
                                        groupdata = await f.json()

                                    with open(basicsetting) as f:
                                        data = json.load(f)
                                        f.close()
                                    main_group_id = data["groupid"]


                                    blacklisted = False
                                    blgroupname = None
                                    if os.path.isfile(desiredpath):
                                        with open(desiredpath) as f:
                                            blacklistdata = json.load(f)
                                            f.close()
                                        
                                        if int(robloxid) in blacklistdata["player"]:
                                            blacklisted = True
                                        else:
                                            i = 0
                                            while i < len(groupdata["data"]):
                                                groupid = groupdata["data"][i]["group"]["id"]

                                                if int(groupid) in blacklistdata["group"]:
                                                    blacklisted = True
                                                    blgroupname = groupdata["data"][i]["group"]["name"]
                                                    break
                                                else:
                                                    i += 1
                                    else:
                                        pass

                                    if blacklisted == False:

                                        mainhit = False
                                        i = 0
                                        while i < len(groupdata["data"]):
                                            group = groupdata["data"][i]["group"]["id"]
                                            if group == main_group_id:
                                                mainhit = True
                                                rankid = groupdata["data"][i]["role"]["rank"]
                                                break
                                            else:
                                                rankid = 0
                                                i += 1
                                    
                                        with open(bindsetting) as f:
                                            binddata = json.load(f)
                                            f.close()
                                        
                                        whitelist = [] 

                                        giverole = []

                                        for x in binddata["whitelisted"]:
                                            whitelist.append(x)

                                        try:
                                            getthisrole = binddata[str(rankid)]
                                            for x in getthisrole:
                                                giverole.append(x)
                                        except:
                                            pass

                                        if mainhit == True:
                                            try:
                                                for x in binddata["maingroup"]:
                                                    giverole.append(x)
                                            except:
                                                pass
                                        
                                        subgroupid = []

                                        subhit = False
                                        i = 0

                                        while i < len(groupdata["data"]):
                                            group = groupdata["data"][i]["group"]["id"]
                                            subgroupid.append(str(group))
                                            i += 1
                                        
                                        for x in subgroupid:
                                            try:
                                                roleid = binddata["subgroup"][x]
                                                giverole.append(roleid)
                                            except:
                                                pass 
                                        
                                        if os.path.isfile(nameset):
                                            with open(nameset) as f:
                                                namesetdata = json.load(f)
                                                f.close()
                                            givenameformat = namesetdata["nameformat"]

                                            with open(nameformat) as f:
                                                namedata = json.load(f)
                                                f.close()
                                            try:
                                                hisnamedata = namedata[str(rankid)]
                                                hisnamedata = hisnamedata[0]
                                            except:
                                                if mainhit == False:
                                                    try:
                                                        hisnamedata = namedata["0"]
                                                        hisnamedata = hisnamedata[0]
                                                    except:
                                                        hisnamedata = None
                                                else:
                                                    hisnamedata = None


                                            targetname = ""
                                            for x in givenameformat:
                                                if x == "1":
                                                    if robloxname == None:
                                                        continue
                                                    else:
                                                        targetname += f"{robloxname}"
                                                elif x == "2":
                                                    if hisnamedata == None:
                                                        continue
                                                    else:
                                                        targetname += f"{hisnamedata}"
                                                elif x == "3":
                                                    targetname += f"{target.name}"
                                                else:
                                                    targetname += x

                                        else:
                                            targetname = target.display_name

                                        #giverole에 없고 whitelist에 없으면 빼고, giverole 주고 이름 바꿔

                                        addresult = ""
                                        removeresult = ""
                                        nameresult = ""

                                        for x in giverole:
                                            myrole = discord.utils.get(ctx.guild.roles, id=int(x))

                                            if myrole in target.roles:
                                                pass
                                            else:
                                                try:
                                                    await target.add_roles(myrole)
                                                    addresult += f"\n+{myrole.mention}"
                                                except:
                                                    continue 
                                        
                                        for x in target.roles:
                                            roleid = x.id 
                                            if roleid in giverole:
                                                continue
                                            else:
                                                if roleid in whitelist:
                                                    continue
                                                else:
                                                    if x.name != "nastybypass":
                                                        try:
                                                            await target.remove_roles(x)
                                                            if x.mention != "@@everyone":
                                                                removeresult += f"\n-{x.mention}"
                                                        except:
                                                            continue

                                        try:
                                            await target.edit(nick=targetname)
                                            nameresult = targetname
                                        except:
                                            nameresult = "Fail(Permission error)"
                                        
                                        embed = discord.Embed(
                                            title = "Success | Updated",
                                            description = f"Name:\n{nameresult}\n\nAdded roles:\n{addresult}\n\nRemoved roles:\n{removeresult}\n\n",
                                            color = discord.Color.from_rgb(0, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                        await ctx.send(embed=embed)
                                    else:
                                        if blgroupname != None:

                                            nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                            for x in target.roles:
                                                try:
                                                    await target.remove_roles(x)
                                                except:
                                                    pass

                                            embed = discord.Embed(
                                                title = "Error | Blacklisted group",
                                                description = f"User trying to be updated is in a blacklisted group.\n`{blgroupname}`",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                            await ctx.send(embed=embed)
                                        else:
                                            nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                            for x in target.roles:
                                                try:
                                                    await target.remove_roles(x)
                                                except:
                                                    pass

                                            embed = discord.Embed(
                                                title = "Error | Blacklisted user",
                                                description = f"User trying to be updated is blacklisted.",
                                                color = discord.Color.from_rgb(255, 0, 0)
                                            )
                                            embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                            await ctx.send(embed=embed)



                                else:

                                    nastybypass = discord.utils.get(ctx.guild.roles, name="nastybypass")

                                    if nastybypass in target.roles:
                                        embed = discord.Embed(
                                            title = "Error | role 'nastybypass'",
                                            description = f"The user has 'nastybypass' role. Only he/she may update him/herself.",
                                            color = discord.Color.from_rgb(255, 255, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                        await ctx.send(embed=embed)
                                    else:
                                        for x in target.roles:
                                            try:
                                                await target.remove_roles(x)
                                            except:
                                                pass

                                        embed = discord.Embed(
                                            title = "Error | User not verified",
                                            description = f"It seems that user isn't verified. All of user's roles are removed.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                        await ctx.send(embed=embed)
                            else:
                                embed = discord.Embed(
                                    title = "Error | Server not setted up",
                                    description = f"Please tell the owner to set the server up.\nWe currently don't support english version of server setup.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                await ctx.send(embed=embed)
                        else:
                                embed = discord.Embed(
                                    title = "Error | role 'nastybypass'",
                                    description = f"The user has 'nastybypass' role. Only he/she may update him/herself.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "Error | Server not setted up",
                        description = f"Please tell the owner to set the server up.\nWe currently don't support english version of server setup.",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                    await ctx.send(embed=embed)
        else:
            purchaseadviceprompt = discord.Embed(
                title = "서버에 봇 사용권을 구매 해주세요",
                description = f"구매방법:\n<:bobux:799596446855725057> 로벅스: 1,000 Robux,\n<:cultureland:829254798577631243> 문화상품권: ₩5,000\n<:toss:879560224258805780> 계좌: ₩4,000\n```한 번의 구매는 서버 하나의 네스티코어 평생(서비스 유지 기간동안) 이용을 보증합니다```\n구매 방법: https://discord.gg/jsfxCgDMye 가입 후 설명 확인",
                color = discord.Color.from_rgb(255, 255, 0)
            )
            purchaseadviceprompt.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=purchaseadviceprompt)  

    @commands.command(aliases=["업데이트활성화"])
    async def enableupdate(self, ctx):
        serverid = ctx.guild.id
        shouldupdate = f"client/{serverid}/supdate.txt"
        
        try:
            if ctx.author.id == ctx.guild.owner_id or ctx.author.id == ownerid:
                if os.path.isfile(shouldupdate):
                    embed = discord.Embed(
                        title = "에러 | 활성화된 상태",
                        description = f"이미 업데이트가 활성화된 상태입니다. 비활성화를 원하신다면\n```!업데이트비활성화```\n명령어를 사용해주세요.",
                        color = discord.Color.from_rgb(255, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed) 
                else:
                    with open(shouldupdate, "w") as f:
                        f.close()

                    embed = discord.Embed(
                        title = "성공 | 업데이트 활성화",
                        description = f"업데이트가 활성화 되었습니다. 추후에 비활성화를 하고싶다면\n```!업데이트비활성화```\n명령어를 사용해주세요.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed) 
                    
            else:
                embed = discord.Embed(
                    title = "에러 | 권한오류",
                    description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        except:
            embed = discord.Embed(
                title = "에러 | 연동되지 않음",
                description = f"연동된 그룹이 없습니다. `!그룹연동 그룹아이디`를 우선적으로 사용해주세요.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)


    @commands.command(aliases=["업데이트비활성화"])
    async def disableupdate(self, ctx):
        serverid = ctx.guild.id
        shouldupdate = f"client/{serverid}/supdate.txt"

        if ctx.author.id == ctx.guild.owner_id or ctx.author.id == ownerid:
            if os.path.isfile(shouldupdate):
                os.remove(shouldupdate)

                embed = discord.Embed(
                    title = "성공 | 업데이트 비활성화",
                    description = f"업데이트가 비활성화 되었습니다. 추후에 활성화를 하고싶다면\n```!업데이트활성화```\n명령어를 사용해주세요.",
                    color = discord.Color.from_rgb(0, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed) 

            else:
                embed = discord.Embed(
                    title = "에러 | 비활성화된 상태",
                    description = f"이미 업데이트가 비활성화된 상태입니다. 활성화를 원하신다면\n```!업데이트활성화```\n명령어를 사용해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)        
        else:
            embed = discord.Embed(
                title = "에러 | 권한오류",
                description = f"이 명령어는 보안상의 이유로 서버 주인만 사용 가능합니다.",
                color = discord.Color.from_rgb(255, 0, 0)
            )
            embed.set_footer(text="NastyCore, The Next Innovation")
            await ctx.send(embed=embed)


def setup(client):
    client.add_cog(update(client))