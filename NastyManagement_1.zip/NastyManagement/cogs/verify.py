import discord
import os
import json
from discord.ext import commands
import requests
import random
import asyncio
req = requests.Session()
#verify, unverify mypath -> vpspath

def getcommand(ctx):
    splitlist = ctx.split(" ")[0]
    return splitlist

class verify(commands.Cog):

    def __init__(self, client):
        self.client = client
    
    @commands.command(aliases=["인증"])
    async def verify(self, ctx):
        if getcommand(ctx.message.content) == "!인증":
            discordid = ctx.author.id

            vdbpath = "server/verificationdb"

            verifyplaceholder = vdbpath+"/placeholder.json"
            verifydb = vdbpath+f"/db/{discordid}.json"
            lobby = vdbpath+f"/lobby/{discordid}.json"

            if os.path.isfile(verifydb):

                with open(verifydb) as f:
                    data = json.load(f)
                    f.close()
                
                robloxname = data["robloxname"]
                robloxid = data["robloxid"]

                embed = discord.Embed(
                    title = "에러 | 인증된 유저",
                    description = f"{ctx.author.mention}님은 현재 {robloxname}({robloxid})(으)로 인증된 상태입니다.\n인증을 풀고싶다면 `!인증해제`명령어를 사용해주세요.\n업데이트를 하고싶다면 `!업데이트`명령어를 사용해주세요.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)

            else:

                embed= discord.Embed(
                    title = "선택 | 인증 방법",
                    description = f"1️⃣ - 수동인증(코드 입력)\n2️⃣ - Rover 인증계정으로 자동등록\n❌ - 종료",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                prompt = await ctx.send(content = ctx.author.mention, embed=embed)
                
                onetwo = ["1️⃣", "2️⃣", "❌"]
                for i in onetwo:
                    await prompt.add_reaction(i)
            
                def firstcheck(reaction, user):
                    return reaction.message.id == prompt.id and str(reaction.emoji) in onetwo and user == ctx.author

                def chatcheck(author):
                    def inner_check(message):
                        return message.author.id == author
                    return inner_check

                try:
                    reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 30)

                    await prompt.clear_reactions()

                    if reaction.emoji == "1️⃣":
                        embed = discord.Embed(
                            title = "입력 | 로블록스 이름",
                            description = f"인증할 로블록스 이름을 입력해주세요.\n```NastyCore```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        robloxname = await ctx.send(content= ctx.author.mention, embed=embed)

                        try:
                            msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 120)
                        except asyncio.exceptions.TimeoutError:
                            embed= discord.Embed(
                                title = "에러 | 시간초과",
                                description = f"답장이 너무 오래걸려 프로세스가 종료되었습니다.",
                                color = discord.Color.from_rgb(255, 0, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await robloxname.edit(embed=embed)
                        finally:
                            robloxname = msg.content
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={robloxname}").json()

                            try:
                                robloxid = r["Id"]
                                robloxname = r["Username"]
                                
                                wordlist = [
                                    "happy",
                                    "sad",
                                    "clown",
                                    "movie",
                                    "korea",
                                    "korea",
                                    "usa",
                                    "roblox",
                                    "apple",
                                    "kiwi",
                                    "guest",
                                    "army",
                                    "school",
                                    "mad",
                                    "tasty",
                                    "yum",
                                    "pizza",
                                    "chicken"
                                ]
                                result = "CORE"
                                i = 0
                                while i < 4:
                                    randomnumber = random.randrange(0, 16)
                                    result += f" {wordlist[randomnumber]}"
                                    i += 1
                                

                                with open(verifyplaceholder) as f:
                                    data = json.load(f)
                                    f.close()

                                data["robloxname"] = robloxname
                                data["robloxid"] = robloxid
                                data["code"] = result

                                with open(lobby, "w") as f:
                                    json.dump(data, f, indent=2)
                                    f.close()

                                embed = discord.Embed(
                                    title = "인증 | 코드 입력",
                                    description = f"{robloxname}(으)로 인증을 시도중입니다.\n계정의 소유권을 인증하기 위해 다음 코드를 [로블록스 **설명란**](https://www.roblox.com/users/{robloxid}/profile)에 기입해주세요.\n```{result}```\n기입하셨으면 '완료', 인증을 취소하시려면 '취소'를 입력해주세요.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                embed.set_image(url="https://i.gyazo.com/thumb/1200/04b7fb926869f2744d57add7a238de6e-png.jpg")
                                embed.set_thumbnail(url=f"http://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username={robloxname}")
                                codewrite = await ctx.send(embed=embed)

                                def check(author):
                                    def inner_check(message):
                                        return message.author.id == author and message.content == "완료" or message.author.id == author and message.content == "취소"
                                    return inner_check
                                
                                try:
                                    msg = await self.client.wait_for('message', check=check(ctx.author.id), timeout = 300.0)
                                except asyncio.exceptions.TimeoutError:
                                    embed= discord.Embed(
                                        title = "에러 | 시간초과",
                                        description = f"답장이 너무 오래걸려 프로세스가 종료되었습니다.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation")
                                    await codewrite.edit(embed=embed)
                                else:                
                                    if msg.content == "완료":

                                        discordid = msg.author.id
                                        verifydb = vdbpath+f"/db/{discordid}.json"
                                        lobby = vdbpath+f"/lobby/{discordid}.json"

                                        with open(lobby) as f:
                                            data = json.load(f)
                                            f.close()

                                        robloxid = data["robloxid"]
                                        code = data["code"]
                                        robloxname = data["robloxname"]

                                        r = req.get(f"https://users.roblox.com/v1/users/{robloxid}/status").json()

                                        r2 = req.get(f"https://users.roblox.com/v1/users/{robloxid}").json()

                                        try:
                                            statusmessage = r["status"]
                                            descriptionmessage = r2["description"]

                                            if statusmessage == code or descriptionmessage == code:
                                                with open(verifydb, "w") as f:
                                                    json.dump(data, f, indent=2)
                                                    f.close()
                                                
                                                os.remove(lobby)

                                                embed = discord.Embed(
                                                    title = "성공 | 인증",
                                                    description = f"{robloxname}(으)로 인증이 완료됐습니다.\n서버 주인이 설정을 했다면 `!업데이트`를 통해 역할을 받으실 수 있습니다.",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await ctx.send(embed=embed)

                                            else:
                                                
                                                os.remove(lobby)

                                                embed = discord.Embed(
                                                    title = "에러 | 코드 불일치",
                                                    description = f"{robloxname}님의 상태 메세지: `{descriptionmessage}`\n요청한 상태 메세지: `{code}`\n다시 인증해주세요.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation")
                                                await ctx.send(embed=embed)
                                            

                                        except:
                                            await ctx.send("예상되지 않은 에러. 다시 시도 바람.")
                                    

                                    elif msg.content == "취소":
                                        os.remove(lobby)
                                        embed = discord.Embed(
                                            title = "취소 | 인증",
                                            description = f"{msg.author.mention}, 인증이 취소됐습니다.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation")
                                        await ctx.send(embed=embed)
                                    else:
                                        return


                            except:
                                embed = discord.Embed(
                                    title = "에러 | 유저이름 존재여부",
                                    description = f"제공하신 로블록스 이름 '{robloxname}'은(는) 존재하지 않습니다.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation")
                                await ctx.send(embed=embed)
                    elif reaction.emoji == "2️⃣":

                        r = req.get(f"https://verify.eryn.io/api/user/{user.id}").json()
                        status = r["status"]

                        if status == "ok":
                            robloxname = r["robloxUsername"]
                            robloxid = r["robloxId"]

                            with open(verifyplaceholder) as f:
                                data = json.load(f)
                                f.close()
                            
                            data["robloxname"] = robloxname
                            data["robloxid"] = robloxid
                            data["code"] = "rover"

                            with open(verifydb, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()

                            embed = discord.Embed(
                                title = "성공 | 인증",
                                description = f"{robloxname}(으)로 인증이 완료됐습니다.\n서버 주인이 설정을 했다면 `!업데이트`를 통해 역할을 받으실 수 있습니다.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            embed.set_thumbnail(url=f"http://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username={robloxname}")
                            await prompt.edit(embed=embed)

                        else:
                            embed= discord.Embed(
                                title = "에러 | Rover 데이터가 없음",
                                description = f"Rover 데이터베이스에서 해당 디스코드 계정과 연동된 로블록스 게정을 찾지 못했습니다.\n수동 인증 부탁드립니다.",
                                color = discord.Color.from_rgb(255, 0, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation")
                            await prompt.edit(embed=embed)    

                    else:
                        embed= discord.Embed(
                            title = "프로세스 종료",
                            description = f"성공적으로 프로세스가 종료되었습니다.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation")
                        await prompt.edit(embed=embed)           
                except asyncio.exceptions.TimeoutError:
                    embed= discord.Embed(
                        title = "에러 | 시간초과",
                        description = f"답장이 너무 오래걸려 프로세스가 종료되었습니다.",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await prompt.edit(embed=embed)
        else:
            discordid = ctx.author.id

            vdbpath = "server/verificationdb"

            verifyplaceholder = vdbpath+"/placeholder.json"
            verifydb = vdbpath+f"/db/{discordid}.json"
            lobby = vdbpath+f"/lobby/{discordid}.json"

            if os.path.isfile(verifydb):

                with open(verifydb) as f:
                    data = json.load(f)
                    f.close()
                
                robloxname = data["robloxname"]
                robloxid = data["robloxid"]

                embed = discord.Embed(
                    title = "Error | Already verified",
                    description = f"{ctx.author.mention}, you are currently verified with {robloxname}({robloxid}).\nto **unverify** your account, please use `!unverify`.\nto update, consider doing `!update`.",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                await ctx.send(embed=embed)

            else:

                embed= discord.Embed(
                    title = "Selection | Verification Method",
                    description = f"1️⃣ - Code verification\n2️⃣ - Verify via Rover database\n❌ - Exit",
                    color = discord.Color.from_rgb(255, 255, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                prompt = await ctx.send(content = ctx.author.mention, embed=embed)
                
                onetwo = ["1️⃣", "2️⃣", "❌"]
                for i in onetwo:
                    await prompt.add_reaction(i)
            
                def firstcheck(reaction, user):
                    return reaction.message.id == prompt.id and str(reaction.emoji) in onetwo and user == ctx.author

                def chatcheck(author):
                    def inner_check(message):
                        return message.author.id == author
                    return inner_check

                try:
                    reaction, user = await self.client.wait_for("reaction_add", check=firstcheck, timeout = 30)

                    await prompt.clear_reactions()

                    if reaction.emoji == "1️⃣":
                        embed = discord.Embed(
                            title = "Enter | Roblox username",
                            description = f"Please enter the roblox username you wish to get verified with.\n```ex) NastyCore```",
                            color = discord.Color.from_rgb(255, 255, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                        robloxname = await ctx.send(content= ctx.author.mention, embed=embed)

                        try:
                            msg = await self.client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 120)
                        except asyncio.exceptions.TimeoutError:
                            embed= discord.Embed(
                                title = "Error | Timeout",
                                description = f"It took you a bit too long to answer. Please re-run the process.",
                                color = discord.Color.from_rgb(255, 0, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                            await robloxname.edit(embed=embed)
                        finally:
                            robloxname = msg.content
                            r = req.get(f"https://api.roblox.com/users/get-by-username?username={robloxname}").json()
                            try:
                                robloxid = r["Id"]
                                robloxname = r["Username"]
                                
                                wordlist = [
                                    "happy",
                                    "sad",
                                    "clown",
                                    "movie",
                                    "korea",
                                    "korea",
                                    "usa",
                                    "roblox",
                                    "apple",
                                    "kiwi",
                                    "guest",
                                    "army",
                                    "school",
                                    "mad",
                                    "tasty",
                                    "yum",
                                    "pizza",
                                    "chicken"
                                ]
                                result = "CORE"
                                i = 0
                                while i < 4:
                                    randomnumber = random.randrange(0, 16)
                                    result += f" {wordlist[randomnumber]}"
                                    i += 1

                                with open(verifyplaceholder) as f:
                                    data = json.load(f)
                                    f.close()

                                data["robloxname"] = robloxname
                                data["robloxid"] = robloxid
                                data["code"] = result

                                with open(lobby, "w") as f:
                                    json.dump(data, f, indent=2)
                                    f.close()

                                embed = discord.Embed(
                                    title = "Final Step | Enter the given code.",
                                    description = f"You are trying to verify with {robloxname}.\nTo ensure the ownership of the following account, please enter the given code in your roblox's about section.\n```{result}```\nWhen done, say 'done' to continue, 'cancel' to cancel the process.",
                                    color = discord.Color.from_rgb(255, 255, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                embed.set_image(url="https://i.gyazo.com/thumb/1200/04b7fb926869f2744d57add7a238de6e-png.jpg")
                                embed.set_thumbnail(url=f"http://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username={robloxname}")
                                codewrite = await ctx.send(embed=embed)

                                def check(author):
                                    def inner_check(message):
                                        return message.author.id == author and message.content == "done" or message.author.id == author and message.content == "cancel"
                                    return inner_check
                                
                                try:
                                    msg = await self.client.wait_for('message', check=check(ctx.author.id), timeout = 300.0)
                                except asyncio.exceptions.TimeoutError:
                                    embed= discord.Embed(
                                        title = "Error | Timeout",
                                        description = f"It took you a bit too long to answer. Please re-run the process.",
                                        color = discord.Color.from_rgb(255, 0, 0)
                                    )
                                    embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                    await robloxname.edit(embed=embed)
                                else:                
                                    if msg.content == "done":

                                        discordid = msg.author.id
                                        verifydb = vdbpath+f"/db/{discordid}.json"
                                        lobby = vdbpath+f"/lobby/{discordid}.json"

                                        with open(lobby) as f:
                                            data = json.load(f)
                                            f.close()

                                        robloxid = data["robloxid"]
                                        code = data["code"]
                                        robloxname = data["robloxname"]

                                        r = req.get(f"https://users.roblox.com/v1/users/{robloxid}/status").json()

                                        r2 = req.get(f"https://users.roblox.com/v1/users/{robloxid}").json()

                                        try:
                                            statusmessage = r["status"]
                                            descriptionmessage = r2["description"]

                                            if statusmessage == code or descriptionmessage == code:
                                                with open(verifydb, "w") as f:
                                                    json.dump(data, f, indent=2)
                                                    f.close()
                                                
                                                os.remove(lobby)

                                                embed = discord.Embed(
                                                    title = "Success | Verification Complete",
                                                    description = f"You are now verified with {robloxname}.\nYou can use '!update' to get your roles updated assuming the owner had setted the server up.",
                                                    color = discord.Color.from_rgb(0, 255, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                                await ctx.send(embed=embed)

                                            else:
                                                
                                                os.remove(lobby)

                                                embed = discord.Embed(
                                                    title = "Error | Code mismatch",
                                                    description = f"{robloxname}'s status message: `{descriptionmessage}`\Requested code: `{code}`\nPlease reverify.",
                                                    color = discord.Color.from_rgb(255, 0, 0)
                                                )
                                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                                await ctx.send(embed=embed)
                                            

                                        except:
                                            await ctx.send("Unexpected error. Please retry.")
                                    

                                    elif msg.content == "cancel":
                                        os.remove(lobby)
                                        embed = discord.Embed(
                                            title = "cancellation | Verification",
                                            description = f"{msg.author.mention}, you cancelled the verification process.",
                                            color = discord.Color.from_rgb(255, 0, 0)
                                        )
                                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                        await ctx.send(embed=embed)
                                    else:
                                        return


                            except:
                                embed = discord.Embed(
                                    title = "Error | Roblox user not found",
                                    description = f"Roblox name you provided, '{robloxname}' doesn't seem to exist.",
                                    color = discord.Color.from_rgb(255, 0, 0)
                                )
                                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                                await ctx.send(embed=embed)
                    elif reaction.emoji == "2️⃣":

                        r = req.get(f"https://verify.eryn.io/api/user/{user.id}").json()
                        status = r["status"]

                        if status == "ok":
                            robloxname = r["robloxUsername"]
                            robloxid = r["robloxId"]

                            with open(verifyplaceholder) as f:
                                data = json.load(f)
                                f.close()
                            
                            data["robloxname"] = robloxname
                            data["robloxid"] = robloxid
                            data["code"] = "rover"

                            with open(verifydb, "w") as f:
                                json.dump(data, f, indent=2)
                                f.close()

                            embed = discord.Embed(
                                title = "Success | Verification Complete",
                                description = f"You are now verified with {robloxname}.\nYou can use '!update' to get your roles updated assuming the owner had setted the server up.",
                                color = discord.Color.from_rgb(0, 255, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                            embed.set_thumbnail(url=f"http://www.roblox.com/Thumbs/Avatar.ashx?x=150&y=150&Format=Png&username={robloxname}")
                            await prompt.edit(embed=embed)

                        else:
                            embed= discord.Embed(
                                title = "Error | Rover database not found",
                                description = f"We couldn't find your data in Rover database.\nPlease verify via code.",
                                color = discord.Color.from_rgb(255, 0, 0)
                            )
                            embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                            await prompt.edit(embed=embed)    

                    else:
                        embed= discord.Embed(
                            title = "cancellation | Verification",
                            description = f"The process was successfully cancelled.",
                            color = discord.Color.from_rgb(255, 0, 0)
                        )
                        embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                        await prompt.edit(embed=embed)           
                except asyncio.exceptions.TimeoutError:
                    embed= discord.Embed(
                        title = "Error | Timeout",
                        description = f"It took you a bit too long to answer. Please re-run the process.",
                        color = discord.Color.from_rgb(255, 0, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                    await robloxname.edit(embed=embed)

    @commands.command(aliases=["인증해제"])
    async def unverify(self, ctx):
        if getcommand(ctx.message.content) == "!인증해제":
            discordid = ctx.author.id
            vdbpath = "server/verificationdb"
            verifydb = vdbpath+f"/db/{discordid}.json"
            
            if os.path.isfile(verifydb):
                thislist = []
                
                result = "제거된 역할"

                for x in ctx.author.roles:
                    thislist.append(x.name)
                
                for x in thislist:
                    role = discord.utils.get(ctx.guild.roles, name=x)
                    try:
                        await ctx.author.remove_roles(role)
                        result += f"\n-{role.mention}"
                    except:
                        continue
                
                os.remove(verifydb)

                if result == "제거된 역할":
                    embed = discord.Embed(
                        title = "성공 | 인증해제",
                        description = f"권한이 없어 역할을 제거하지 못하였습니다.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "성공 | 인증해제",
                        description = f"{result}",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "실패 | 안증필요",
                    description = f"인증이 안된 상태입니다. 인증을 해주세요.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation")
                await ctx.send(embed=embed)
        else:
            discordid = ctx.author.id
            vdbpath = "server/verificationdb"
            verifydb = vdbpath+f"/db/{discordid}.json"
            
            if os.path.isfile(verifydb):
                thislist = []
                
                result = "Removed roles"

                for x in ctx.author.roles:
                    thislist.append(x.name)
                
                for x in thislist:
                    role = discord.utils.get(ctx.guild.roles, name=x)
                    try:
                        await ctx.author.remove_roles(role)
                        result += f"\n-{role.mention}"
                    except:
                        continue
                
                os.remove(verifydb)

                if result == "Removed roles":
                    embed = discord.Embed(
                        title = "Success | Unverified",
                        description = f"I couldn't remove your roles.",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                    await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title = "Success | Unverified",
                        description = f"{result}",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                    await ctx.send(embed=embed)
            else:
                embed = discord.Embed(
                    title = "Error | User not verified",
                    description = f"It seems that you aren't verified. Try `!verify` first.",
                    color = discord.Color.from_rgb(255, 0, 0)
                )
                embed.set_footer(text="NastyCore, The Next Innovation | ENG")
                await ctx.send(embed=embed)
       

def setup(client):
    client.add_cog(verify(client))