from types import DynamicClassAttribute
from typing import Text
import discord
from discord.ext import commands, tasks
import random 
import requests
import asyncio

req = requests.Session()

intents = discord.Intents.default()
intents.typing = True
intents.presences = True
intents.members = True

ownerid = 631441731350691850
currentdate = 1
client = commands.Bot(command_prefix = '.', intents=intents)
client.remove_command('help')

customerpath = "customer/data"

@client.event
async def on_ready():
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name=".help | 진상 항의전화 무시하는중"))
    print("Bot is ready!")   
@client.event
async def on_command_error(ctx, error): 
    if isinstance(error, commands.CommandOnCooldown):
        return await ctx.send(f'쿨다운 대기중입니다 ({error})')




@client.event
async def on_member_join(member):
    whatlist = [
        f"{member.mention}님, 안녕하십니까! 고객 지원부서 팀장 리정혁입니다. 질문이 있으시면 `!도움말` 명령어로 절 불러주세요~",
        f"{member.mention}님, 안녕하십니까 고객님, 삼성에서 구조조정 당하고 여기에 취직한 김팀장입니다! 질문이 있으시면 `!도움말` 명령어로 절 불러주세요~",
        f"{member.mention} 자네 근무 첫날부터 늦을꺼야? 아.. 고객이라고요..? 몰라봐서 죄송합니다.. 질문이 있으시면 `!도움말` 명령어로 절 불러주세요~",
        f"{member.mention}님, 환영합니다! 네? 근무시간에 도박하면 안되는거 아니냐고요? 에이 ㅋㅋ 사장님만 모르면 되죠. 질문이 있으시면 `!도움말` 명령어로 절 불러주세요~",
        f"{member.mention}님이 하늘에서 날라왔습니다(창문 기물파손). 질문이 있으시면 `!도움말` 명령어로 절 불러주세요~",
        f"{member.mention}님이 들어왔습니다. 보안팀, 무기 들고있는지 확인해주세요. 질문이 있으시면 `!도움말` 명령어로 절 불러주세요~",
    ]
    welcomechannel = discord.utils.get(client.get_all_channels(), id = 792940679189364776)
    randomnumber = random.randint(0, 5)
    await welcomechannel.send(whatlist[randomnumber])

@client.event
async def on_raw_reaction_add(payload):
    user = client.get_user(payload.user_id)
    if not user.bot:
        openticketmsgid = 810120267929223190

        if payload.message_id == openticketmsgid:
            if payload.emoji.name == "🆘":
                channel = client.get_channel(payload.channel_id)
                message = await channel.fetch_message(payload.message_id)
                user = client.get_user(payload.user_id)
                await message.remove_reaction("🆘", user)

                try:
                    ticketchannel = discord.utils.get(client.get_all_channels(), name = str(payload.user_id))

                    await ticketchannel.send(f"{user.mention} 현재 진행중인 티켓이 있습니다")
                except:
                    guild = client.get_guild(payload.guild_id)
                    category = discord.utils.get(guild.categories, name="티켓")
                    await guild.create_text_channel(str(payload.user_id), category=category)

                    targetchannel = ticketchannel = discord.utils.get(client.get_all_channels(), name = str(payload.user_id))
                    await targetchannel.set_permissions(user, read_messages=True, send_messages=True)

                    await targetchannel.send("<@&792563900403023892>")

                    embed = discord.Embed(
                        title = f"새로운 티켓 | {payload.user_id}",
                        description = f"{user.mention}님 질문, 문의, 또는 이 티켓을 연 이유를 남겨두십시오. 곧 지원팀이 와서 도와드릴껍니다.\n```[*] 모든 행동은 저장되며 트롤시 지원 채널을 이용할 혜택을 잃을수있습니다\n[*] 트롤 방지를 위해 티켓을 닫는것은 직원만 가능합니다\n[*] 직원을 향한 폭언을 삼가해주시고 직원이 폭언을 한다면 증거사진후 서버 주인에게 제출 바랍니다```",
                        color = discord.Color.from_rgb(0, 255, 0)
                    )
                    embed.set_footer(text="NastyCore, The Next Innovation")
                    embed1 = await targetchannel.send(embed=embed)
                    await embed1.add_reaction("🔒")
                    await embed1.add_reaction("🚩")



        else:
            emojilist = ["🔒", "🚩" ]
            if payload.emoji.name in emojilist:
                user = client.get_user(payload.user_id)
                guild = client.get_guild(payload.guild_id)
                member = guild.get_member(payload.user_id)
                channel = client.get_channel(payload.channel_id)
                message = await channel.fetch_message(payload.message_id)
                
                customerowner = discord.utils.get(guild.roles, id=792563900403023892)
                targetchannel = discord.utils.get(client.get_all_channels(), id = payload.channel_id)

                if customerowner in member.roles:
                    if payload.emoji.name == "🔒":
                        await targetchannel.delete()
                    else:
                        reportchannel = discord.utils.get(client.get_all_channels(), id = 810130677068070932)

                        await targetchannel.send("신고가 접수되었습니다. 현장보존을 위해 채널을 닫지 말아주십시오")

                        await reportchannel.send(f"{targetchannel.name} | reporter: {member.mention}")
                else:
                    try:
                        int(targetchannel.name)
                        await targetchannel.send("현재 이 기능의 악용을 막기 위해 유저 스스로 채널을 닫을수없게 설정했습니다")
                        if payload.emoji.name == "🔒":
                            await message.remove_reaction("🔒", user)
                        else:
                            await message.remove_reaction("🚩", user)


                    except:
                        pass

@client.command(aliases=["도움말"])
async def help(ctx):
    await ctx.send("제작중, 도움이 필요하면 지금은 <#810119773035823154> 채널을 이용해주세요")

@client.command()
async def statuschange(ctx, what):
    if ctx.author.id == ownerid:
        statuschannel = discord.utils.get(client.get_all_channels(), id = 815571295177408542)

        mydict = {
            "red" : "🔴",
            "yellow" : "🟡",
            "green" : "🟢",
            "dev" : "🚧"
        }

        color = mydict[what]

        result = f"봇 상태{color}"

        await statuschannel.edit(name = result)

@client.command(aliases=["포스트", "구매", "판매"])
@commands.cooldown(2, 3600, commands.BucketType.user)
async def post(ctx):
    try:
        serverid = ctx.guild.id

        embed= discord.Embed(
            title = "개인 채팅에서 사용해주세요",
            description = f"ㄳ",
            color = discord.Color.from_rgb(255, 255, 0)
        )
        embed.set_footer(text="NastyCore, The Next Innovation")
        await ctx.send(embed=embed)
    except:
        title = "a"
        desc = "b"
        price = "c"

        onetwo = ["1️⃣", "2️⃣"]
        yesno = ["⭕", "❌"]

        ####################################################################################
        #맨 처음 질문
        embed_question = discord.Embed(
            title = "구매/판매중 하나를 선택해주세요",
            description = f"1️⃣ - 구매(물건을 구하는 용도)\n2️⃣ - 판매(물건을 판매하는 용도)",
            color = discord.Color.from_rgb(255, 255, 0)
        )
        embed_question.set_footer(text="NastyCore, The Next Innovation")

        #타임아웃
        embed_timeout = discord.Embed(
            title = "프로세스 종료",
            description = "시간이 너무 오래걸려 프로세스가 종료되었습니다.",
            color = discord.Color.from_rgb(255, 0, 0)
        )
        embed_timeout.set_footer(text="NastyCore, The Next Innovation")

        #제품이름
        embed_productname = discord.Embed(
            title = "구매/판매할 제품의 이름",
            description = "구매/판매할 제품의 이름을 알려주세요.",
            color = discord.Color.from_rgb(255, 255, 0)
        )
        embed_productname.set_footer(text="NastyCore, The Next Innovation")

        #제품설정
        embed_contextques = discord.Embed(
            title = "구매/판매할 제품 설명",
            description = "구매/판매할 제품을 가급적 자세히 설명해주세요. 보낼때 이용된 형식 그대로 보내집니다.",
            color = discord.Color.from_rgb(255, 255, 0)
        )
        embed_contextques.set_footer(text="NastyCore, The Next Innovation")

        #제품가격
        embed_price = discord.Embed(
            title = "구매/판매할 제품 가격",
            description = "구매/판매할 제품의 가격을 알려주세요. 문화상품권, 계좌등 받으시는 종류와 원 단위를 정확히 입력해주세요.",
            color = discord.Color.from_rgb(255, 255, 0)
        )
        embed_price.set_footer(text="NastyCore, The Next Innovation")

        #규정
        embed_tos = discord.Embed(
            title = "규정 동의서",
            description = "규정을 **자세히** 읽고 동의/비동의 부탁드립니다.\n```[*] 모든 방식의 홍보는 불가하며 적발 시 봇 사용 권한을 잃고, 서버에서 추방을 당하실 수 있습니다.\n[*] 디스코드 규정에 어긋나는 제품은 구매/판매하실 수 없습니다(툴, 핵, 바이러스..등등)\n[*] 거래중 사기치는것이 적발되면 봇 사용 권한을 잃고, 서버에서 추방을 당하실 수 있습니다.```",
            color = discord.Color.from_rgb(255, 255, 0)
        )
        embed_tos.set_footer(text="NastyCore, The Next Innovation")



        original = await ctx.send(content = ctx.author.mention,embed=embed_question)
        for x in onetwo:
            await original.add_reaction(x)

        ########################################################################
        #1, 2선택
        def firstcheck(reaction, user):
            return reaction.message.id == original.id and str(reaction.emoji) in onetwo and user == ctx.author

        #대답
        def chatcheck(author):
            def inner_check(message):
                return message.author.id == author
            return inner_check

        def protect(a):
            protectionlist = ["https://", "www.", "discord", "discord.gg", "invite", "초대", "핵", "툴", "해킹"]
            detection = False
            for i in protectionlist:
                if i in a:
                    detection = True
                    break
                else:
                    pass

            if detection == True:
                return "검열"
            else:
                return a


        #########################################################################

        try:
            reaction, user = await client.wait_for("reaction_add", check=firstcheck, timeout = 15)

            if reaction.emoji == "1️⃣":
                destination = 821547399625048064
            else:
                destination = 821563464912732181
            
            await ctx.send(embed=embed_productname)

            try:
                msg = await client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 60.0)
                
                title = protect(msg.content)

                context = await ctx.send(content=ctx.author.mention, embed=embed_contextques)

                try:
                    msg = await client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 300)

                    desc = protect(msg.content)

                    priceask = await ctx.send(content=ctx.author.mention, embed=embed_price)

                    try:
                        msg = await client.wait_for('message', check=chatcheck(ctx.author.id), timeout = 60.0)
                        
                        price = protect(msg.content)

                        embed_final = discord.Embed(
                            title = title,
                            description = f"제품설명:\n```{desc}```\n가격:\n```{price}```",
                            color = discord.Color.from_rgb(0, 255, 0)
                        )
                        embed_final.set_footer(text="NastyCore, The Next Innovation")

                        channel = discord.utils.get(client.get_all_channels(), id = destination)

                        await channel.send(content=ctx.author.mention, embed=embed_final)
                        await channel.send("혹시 거래중 판매자/구매자가 이상한 행동을 보일시 지체하지말고 신고해주세요. 사기조심!")


                    except asyncio.exceptions.TimeoutError:
                        await priceask.edit(embed=embed_timeout)

                except asyncio.exceptions.TimeoutError:
                    await context.edit(embed=embed_timeout)
            

            except asyncio.exceptions.TimeoutError:
                await original.edit(embed=embed_timeout)


        except asyncio.exceptions.TimeoutError:
            await original.edit(embed=embed_timeout)


client.run("ODEwMDQ0OTU2NDExNTU5OTM3.YCd7Jw.ZuJUj1UF99an4TeDFv6xNgHeQYo")