import discord
import os
import json
import requests
from discord.ext import commands, tasks

client = commands.Bot(command_prefix = "!")
client.remove_command('help')
#Verify MyPath 수정
#groupbind MyPath 수정

#############################################################
#쿠키저장
mycookie = "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_7E4C1FC77B0D9EE9869AF1B08E34A0C971D1FD1800A5D085AC4AF4769CCFE7440739F6B856C679F5AA2EEC0A2407ED58AEA5F6688D24D9671CDF5E68CC05D6A532C58C37EDB2A36E29FD9608AF9F364D909757542CD99E5D89E671CAA2017F2193C44DC7BC9C96932FEBC1B21190B13838FE9C43455BA25F66CB45809B2ACF92AEE8A650151A69406490F3C9689C2B9DA5B724DFC00323D0AAC69680B6DD3BFB271F3AC9D1511583D0F6CE7A8D7729F976CCC77F9C6100208C1D8E9011330EDE604E80BAF814B29A73B26EE60DACF1706E4C5AE6A526D9DD55F11195861890B09ED068D74CF116C30E9C986419F6ED982F49192FF57B57DA5D44EBD6CCED5AA5212E297B359362D96013D6BDD00DC6B06EABBAC7C9BD7358F42583F2B71A045828D632D8B524716AF55C6A9B54B1E2CECEB48820"
req = requests.Session()
req.cookies[".ROBLOSECURITY"] = mycookie


for filename in os.listdir("cogs"):
    if filename.endswith(".py"):
        client.load_extension(f"cogs.{filename[:-3]}")

@client.command()
async def load(ctx, name):
    client.load_extension(f"cogs.{name}")
    await ctx.send("Done!")

@client.command()
async def unload(ctx, name):
    client.unload_extension(f"cogs.{name}")
    await ctx.send("Done!")








client.run("NzkyOTY4NzU1Njc5ODU0NjAy.X-lbtA.PrrmEgoO-fFBlEBB5_19D_Wv5ys")